package thelostsoulsyeyeye.client.sound;

import net.minecraft.client.resources.sounds.AbstractTickableSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import thelostsoulsyeyeye.client.ClientFractureState;
import thelostsoulsyeyeye.registry.ModSounds;

/**
 * A looping heartbeat inside the player's head. It gets louder and faster the closer one of Them is,
 * and quietly ends itself when nothing is near any more.
 */
public class HeartbeatSound extends AbstractTickableSoundInstance {
	public HeartbeatSound() {
		super(ModSounds.AMBIENT_HEARTBEAT, SoundSource.MASTER, SoundInstance.createUnseededRandom());
		this.looping = true;
		this.delay = 0;
		this.volume = 0.1F;
		this.relative = true;
		this.attenuation = SoundInstance.Attenuation.NONE;
	}

	@Override
	public void tick() {
		float proximity = ClientFractureState.proximity();
		if (proximity < 0.05F) {
			this.stop();
			return;
		}
		this.volume = Mth.clamp(proximity * 1.4F, 0.0F, 1.0F);
		this.pitch = 0.75F + 0.8F * proximity;
	}
}
