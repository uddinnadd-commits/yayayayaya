package thelostsoulsyeyeye.client.model;

import net.minecraft.client.animation.AnimationDefinition;

import static thelostsoulsyeyeye.client.model.Anim.*;

public final class RemnantAnimations {
	private RemnantAnimations() {}

	public static final AnimationDefinition IDLE = AnimationDefinition.Builder.withLength(3.0F).looping()
			.addAnimation("head", rot(r(0.0F, 0, 0, 0), r(1.5F, 0, 16, 0), r(3.0F, 0, 0, 0)))
			.addAnimation("body", rot(r(0.0F, 0, 0, 0), r(1.5F, 1.5F, 0, 0), r(3.0F, 0, 0, 0)))
			.build();

	/** A heavy overhead cleave with the sword arm. */
	public static final AnimationDefinition ATTACK = AnimationDefinition.Builder.withLength(0.8F)
			.addAnimation("body", rot(r(0.0F, 0, 0, 0), r(0.25F, -9, -8, 0), r(0.45F, 16, 12, 0), r(0.8F, 0, 0, 0)))
			.addAnimation("head", rot(r(0.0F, 0, 0, 0), r(0.25F, -10, 0, 0), r(0.45F, 14, 0, 0), r(0.8F, 0, 0, 0)))
			.addAnimation("right_arm", rot(r(0.0F, 0, 0, 0), r(0.25F, -80, 0, 12), r(0.45F, 105, 0, -6), r(0.8F, 0, 0, 0)))
			.addAnimation("left_arm", rot(r(0.0F, 0, 0, 0), r(0.25F, -30, 0, -10), r(0.45F, 20, 0, 0), r(0.8F, 0, 0, 0)))
			.build();
}
