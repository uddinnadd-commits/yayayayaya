package thelostsoulsyeyeye.client.model;

import net.minecraft.client.model.geom.ModelLayerLocation;
import thelostsoulsyeyeye.Thelostsouls;

public final class ModModelLayers {
	private ModModelLayers() {}

	public static final ModelLayerLocation HOLLOW_WALKER = layer("hollow_walker");
	public static final ModelLayerLocation CRAWLER = layer("crawler");
	public static final ModelLayerLocation STRETCHED = layer("stretched");
	public static final ModelLayerLocation ECHO_HOUND = layer("echo_hound");
	public static final ModelLayerLocation REMNANT = layer("remnant");

	private static ModelLayerLocation layer(String name) {
		return new ModelLayerLocation(Thelostsouls.id(name), "main");
	}
}
