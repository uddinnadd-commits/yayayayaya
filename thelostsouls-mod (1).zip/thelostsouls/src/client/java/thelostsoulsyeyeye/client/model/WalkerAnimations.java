package thelostsoulsyeyeye.client.model;

import net.minecraft.client.animation.AnimationDefinition;

import static thelostsoulsyeyeye.client.model.Anim.*;

/** Hollow Walker: long stretches of stillness broken by sudden jerks, and a wild two-armed slam. */
public final class WalkerAnimations {
	private WalkerAnimations() {}

	/** 3 s loop: the head snaps toward things that are not there; fingers and jaw twitch. */
	public static final AnimationDefinition IDLE = AnimationDefinition.Builder.withLength(3.0F).looping()
			.addAnimation("head", rot(
					snap(0.0F, 0, 0, 0), snap(1.1F, 0, 0, 0), snap(1.18F, -6, 28, 10), snap(1.9F, -6, 28, 10),
					snap(1.98F, 8, -26, -8), snap(2.6F, 8, -26, -8), snap(2.7F, 0, 0, 0), snap(3.0F, 0, 0, 0)))
			.addAnimation("left_arm", rot(snap(0.0F, 0, 0, 0), snap(0.4F, 4, 0, -6), snap(0.55F, 0, 0, 2), snap(1.6F, 0, 0, 0), snap(1.7F, 6, 0, -8), snap(1.85F, 0, 0, 0), snap(3.0F, 0, 0, 0)))
			.addAnimation("left_stump", rot(snap(0.0F, 0, 0, 0), snap(0.4F, 4, 0, -6), snap(0.55F, 0, 0, 2), snap(1.6F, 0, 0, 0), snap(1.7F, 6, 0, -8), snap(1.85F, 0, 0, 0), snap(3.0F, 0, 0, 0)))
			.addAnimation("right_arm", rot(snap(0.0F, 0, 0, 0), snap(1.0F, 0, 0, 0), snap(1.12F, 5, 0, 7), snap(1.3F, 0, 0, 0), snap(2.4F, 6, 0, 9), snap(2.55F, 0, 0, 0), snap(3.0F, 0, 0, 0)))
			.addAnimation("right_stump", rot(snap(0.0F, 0, 0, 0), snap(1.0F, 0, 0, 0), snap(1.12F, 5, 0, 7), snap(1.3F, 0, 0, 0), snap(2.4F, 6, 0, 9), snap(2.55F, 0, 0, 0), snap(3.0F, 0, 0, 0)))
			.addAnimation("jaw", rot(snap(0.0F, 0, 0, 0), snap(0.9F, 0, 0, 0), snap(0.95F, 18, 0, 0), snap(1.0F, 0, 0, 0), snap(2.2F, 0, 0, 0), snap(2.25F, 22, 0, 0), snap(2.3F, 0, 0, 0), snap(3.0F, 0, 0, 0)))
			.build();

	/** 0.9 s: wind up, both arms high, jaw wide, then everything comes down at once. */
	public static final AnimationDefinition ATTACK = AnimationDefinition.Builder.withLength(0.9F)
			.addAnimation("body", rot(r(0.0F, 0, 0, 0), r(0.25F, -15, 0, 0), r(0.45F, 38, 0, 0), r(0.9F, 0, 0, 0)))
			.addAnimation("head", rot(r(0.0F, 0, 0, 0), r(0.25F, -22, 0, 0), r(0.45F, 28, 0, 0), r(0.9F, 0, 0, 0)))
			.addAnimation("jaw", rot(r(0.0F, 0, 0, 0), r(0.2F, 70, 0, 0), r(0.45F, 4, 0, 0), r(0.9F, 0, 0, 0)))
			.addAnimation("left_arm", rot(r(0.0F, 0, 0, 0), r(0.25F, -135, 0, -14), r(0.45F, 25, 0, 6), r(0.9F, 0, 0, 0)))
			.addAnimation("left_stump", rot(r(0.0F, 0, 0, 0), r(0.25F, -135, 0, -14), r(0.45F, 25, 0, 6), r(0.9F, 0, 0, 0)))
			.addAnimation("right_arm", rot(r(0.0F, 0, 0, 0), r(0.25F, -135, 0, 14), r(0.45F, 25, 0, -6), r(0.9F, 0, 0, 0)))
			.addAnimation("right_stump", rot(r(0.0F, 0, 0, 0), r(0.25F, -135, 0, 14), r(0.45F, 25, 0, -6), r(0.9F, 0, 0, 0)))
			.build();
}
