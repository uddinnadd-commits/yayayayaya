package thelostsoulsyeyeye.client.model;

import net.minecraft.client.animation.AnimationDefinition;

import static thelostsoulsyeyeye.client.model.Anim.*;

/** The Stretched: slow, wrong, deliberate. The attack is the only fast thing it does. */
public final class StretchedAnimations {
	private StretchedAnimations() {}

	public static final AnimationDefinition IDLE = AnimationDefinition.Builder.withLength(4.0F).looping()
			.addAnimation("head", rot(r(0.0F, 0, 0, 0), r(1.5F, 6, 0, 10), r(3.0F, -4, 0, -8), r(4.0F, 0, 0, 0)))
			.addAnimation("left_hand", rot(r(0.0F, 0, 0, 0), r(2.0F, 25, 0, 0), r(4.0F, 0, 0, 0)))
			.addAnimation("right_hand", rot(r(0.0F, 0, 0, 0), r(1.0F, 20, 0, 0), r(3.0F, -6, 0, 0), r(4.0F, 0, 0, 0)))
			.build();

	public static final AnimationDefinition ATTACK = AnimationDefinition.Builder.withLength(0.8F)
			.addAnimation("body", rot(r(0.0F, 0, 0, 0), r(0.25F, -12, 0, 0), r(0.5F, 32, 0, 0), r(0.8F, 0, 0, 0)))
			.addAnimation("head", rot(r(0.0F, 0, 0, 0), r(0.25F, -10, 0, 0), r(0.5F, 30, 0, 0), r(0.8F, 0, 0, 0)))
			.addAnimation("left_arm", rot(r(0.0F, 0, 0, 0), r(0.25F, -165, 0, -10), r(0.5F, 35, 0, 8), r(0.8F, 0, 0, 0)))
			.addAnimation("left_stump", rot(r(0.0F, 0, 0, 0), r(0.25F, -165, 0, -10), r(0.5F, 35, 0, 8), r(0.8F, 0, 0, 0)))
			.addAnimation("right_arm", rot(r(0.0F, 0, 0, 0), r(0.3F, -165, 0, 10), r(0.55F, 35, 0, -8), r(0.8F, 0, 0, 0)))
			.addAnimation("right_stump", rot(r(0.0F, 0, 0, 0), r(0.3F, -165, 0, 10), r(0.55F, 35, 0, -8), r(0.8F, 0, 0, 0)))
			.build();
}
