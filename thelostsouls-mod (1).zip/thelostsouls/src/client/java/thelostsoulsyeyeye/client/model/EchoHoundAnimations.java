package thelostsoulsyeyeye.client.model;

import net.minecraft.client.animation.AnimationDefinition;

import static thelostsoulsyeyeye.client.model.Anim.*;

public final class EchoHoundAnimations {
	private EchoHoundAnimations() {}

	public static final AnimationDefinition IDLE = AnimationDefinition.Builder.withLength(2.0F).looping()
			.addAnimation("head", rot(r(0.0F, 0, 0, 0), r(0.5F, 12, 8, 0), r(1.0F, -6, -8, 0), r(2.0F, 0, 0, 0)))
			.addAnimation("left_ear", rot(snap(0.0F, 0, 0, 0), snap(1.4F, 0, 0, 0), snap(1.45F, 0, 0, 22), snap(1.6F, 0, 0, 0), snap(2.0F, 0, 0, 0)))
			.build();

	public static final AnimationDefinition ATTACK = AnimationDefinition.Builder.withLength(0.5F)
			.addAnimation("body", rot(r(0.0F, 0, 0, 0), r(0.15F, -12, 0, 0), r(0.3F, 14, 0, 0), r(0.5F, 0, 0, 0)))
			.addAnimation("head", rot(r(0.0F, 0, 0, 0), r(0.15F, -22, 0, 0), r(0.3F, 36, 0, 0), r(0.5F, 0, 0, 0)))
			.addAnimation("jaw", rot(r(0.0F, 0, 0, 0), r(0.15F, 62, 0, 0), r(0.3F, 0, 0, 0), r(0.5F, 0, 0, 0)))
			.build();
}
