package thelostsoulsyeyeye.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.particle.v1.ParticleFactoryRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.DimensionRenderingRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import thelostsoulsyeyeye.client.model.CrawlerModel;
import thelostsoulsyeyeye.client.model.EchoHoundModel;
import thelostsoulsyeyeye.client.model.HollowWalkerModel;
import thelostsoulsyeyeye.client.model.ModModelLayers;
import thelostsoulsyeyeye.client.model.RemnantModel;
import thelostsoulsyeyeye.client.model.StretchedModel;
import thelostsoulsyeyeye.client.particle.GlassShardParticle;
import thelostsoulsyeyeye.client.render.CorruptedRenderer;
import thelostsoulsyeyeye.client.render.HudOverlay;
import thelostsoulsyeyeye.client.render.SkyEffects;
import thelostsoulsyeyeye.client.render.TheirWorldSky;
import thelostsoulsyeyeye.entity.CrawlerEntity;
import thelostsoulsyeyeye.entity.EchoHoundEntity;
import thelostsoulsyeyeye.entity.HollowWalkerEntity;
import thelostsoulsyeyeye.entity.RemnantEntity;
import thelostsoulsyeyeye.entity.StretchedEntity;
import thelostsoulsyeyeye.net.ModNetworking;
import thelostsoulsyeyeye.registry.ModEntities;
import thelostsoulsyeyeye.registry.ModParticles;
import thelostsoulsyeyeye.world.TheirWorld;

public class ThelostsoulsClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		registerEntities();
		registerNetworking();

		ParticleFactoryRegistry.getInstance().register(ModParticles.GLASS_SHARD, GlassShardParticle.Provider::new);

		ClientTickEvents.END_CLIENT_TICK.register(ClientFractureState::tick);

		// Overworld: corrupt the sky and close in the fog. Their World: replace sky/clouds/weather entirely.
		WorldRenderEvents.AFTER_SETUP.register(SkyEffects::applyFog);
		WorldRenderEvents.BEFORE_ENTITIES.register(SkyEffects::renderOverworld);
		DimensionRenderingRegistry.registerSkyRenderer(TheirWorld.LEVEL_KEY, TheirWorldSky::render);
		DimensionRenderingRegistry.registerCloudRenderer(TheirWorld.LEVEL_KEY, context -> {});
		DimensionRenderingRegistry.registerWeatherRenderer(TheirWorld.LEVEL_KEY, context -> {});

		HudRenderCallback.EVENT.register(HudOverlay::render);
	}

	private static void registerEntities() {
		EntityModelLayerRegistry.registerModelLayer(ModModelLayers.HOLLOW_WALKER, HollowWalkerModel::createBodyLayer);
		EntityModelLayerRegistry.registerModelLayer(ModModelLayers.CRAWLER, CrawlerModel::createBodyLayer);
		EntityModelLayerRegistry.registerModelLayer(ModModelLayers.STRETCHED, StretchedModel::createBodyLayer);
		EntityModelLayerRegistry.registerModelLayer(ModModelLayers.ECHO_HOUND, EchoHoundModel::createBodyLayer);
		EntityModelLayerRegistry.registerModelLayer(ModModelLayers.REMNANT, RemnantModel::createBodyLayer);

		EntityRendererRegistry.register(ModEntities.HOLLOW_WALKER, context ->
				new CorruptedRenderer<HollowWalkerEntity, HollowWalkerModel>(context, new HollowWalkerModel(context.bakeLayer(ModModelLayers.HOLLOW_WALKER)), "hollow_walker", 0.5F));
		EntityRendererRegistry.register(ModEntities.CRAWLER, context ->
				new CorruptedRenderer<CrawlerEntity, CrawlerModel>(context, new CrawlerModel(context.bakeLayer(ModModelLayers.CRAWLER)), "crawler", 0.6F));
		EntityRendererRegistry.register(ModEntities.STRETCHED, context ->
				new CorruptedRenderer<StretchedEntity, StretchedModel>(context, new StretchedModel(context.bakeLayer(ModModelLayers.STRETCHED)), "stretched", 0.4F));
		EntityRendererRegistry.register(ModEntities.ECHO_HOUND, context ->
				new CorruptedRenderer<EchoHoundEntity, EchoHoundModel>(context, new EchoHoundModel(context.bakeLayer(ModModelLayers.ECHO_HOUND)), "echo_hound", 0.5F));
		EntityRendererRegistry.register(ModEntities.REMNANT, context ->
				new CorruptedRenderer<RemnantEntity, RemnantModel>(context, new RemnantModel(context.bakeLayer(ModModelLayers.REMNANT)), "remnant", 0.5F));
	}

	private static void registerNetworking() {
		ClientPlayNetworking.registerGlobalReceiver(ModNetworking.PROGRESS, (client, handler, buf, responseSender) -> {
			float progress = buf.readFloat();
			client.execute(() -> ClientFractureState.onProgress(progress));
		});
		ClientPlayNetworking.registerGlobalReceiver(ModNetworking.FRACTURE_START, (client, handler, buf, responseSender) -> {
			long seed = buf.readLong();
			client.execute(() -> ClientFractureState.onFractureStart(seed));
		});
		ClientPlayNetworking.registerGlobalReceiver(ModNetworking.FRACTURE_END, (client, handler, buf, responseSender) ->
				client.execute(ClientFractureState::onFractureEnd));
		ClientPlayNetworking.registerGlobalReceiver(ModNetworking.ARRIVE, (client, handler, buf, responseSender) ->
				client.execute(ClientFractureState::onArrive));
	}
}
