package thelostsoulsyeyeye.client.render;

import java.util.Random;

import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import thelostsoulsyeyeye.Thelostsouls;
import thelostsoulsyeyeye.fracture.FractureTimeline;

/**
 * The 3D set-pieces of the fracture: tentacles that pour out of the wound and coil around you, and the
 * hundreds of glass shards the sky throws everywhere. Everything is a pure function of (time, seed), so
 * there is no per-object state to keep in sync and no flicker if a frame is dropped.
 */
public final class FractureCinematic {
	private FractureCinematic() {}

	private static final ResourceLocation TENTACLE = Thelostsouls.id("textures/environment/tentacle.png");
	private static final ResourceLocation SHARD = Thelostsouls.id("textures/environment/shard.png");

	private static final int SEGMENTS = 44;
	private static final int SIDES = 8;
	private static final int SHARDS = 170;

	/**
	 * @param radius  sky radius (anything farther than the terrain, nearer than the far plane)
	 * @param t       ticks since the cinematic started (fractional)
	 */
	public static void render(Matrix4f m, float radius, float t, long seed, Vector3f crackDir, float time) {
		if (t < FractureTimeline.CRACK) {
			return;
		}
		renderShards(m, radius, t, seed, crackDir);
		renderTentacles(m, radius, t, seed, crackDir, time);
	}

	// ------------------------------------------------------------------------------------ tentacles
	private static void renderTentacles(Matrix4f m, float radius, float t, long seed, Vector3f crackDir, float time) {
		if (t < FractureTimeline.SLITHER) {
			return;
		}
		Vector3f anchor = new Vector3f(crackDir).mul(radius * 0.86F);
		// the main one reaches for you and does not stop
		float reach = RenderUtil.smooth(FractureTimeline.SLITHER, FractureTimeline.PULL + 10, t);
		float ease = 1.0F - (1.0F - reach) * (1.0F - reach) * (1.0F - reach);
		Vector3f near = new Vector3f(0.0F, -0.7F, 0.0F);
		float coil = RenderUtil.smooth(0.8F, 1.0F, reach);
		drawTentacle(m, radius, anchor, near, ease, coil, time, seed, 1.0F, 1.0F);

		// two more writhe around it, thinner, reaching out to either side
		Quaternionf spread = new Quaternionf();
		for (int i = 0; i < 2; i++) {
			float side = i == 0 ? 1.0F : -1.0F;
			Vector3f a = new Vector3f(anchor).rotate(spread.identity().rotateY(side * 0.16F));
			Vector3f target = new Vector3f(side * 3.5F, 1.5F + i, 5.0F - 2.0F * i);
			float r2 = RenderUtil.smooth(FractureTimeline.SLITHER + 25 + 20 * i, FractureTimeline.PULL + 40, t) * 0.85F;
			drawTentacle(m, radius, a, target, r2, 0.0F, time + 17.0F * (i + 1), seed + 31L * (i + 1), 0.55F, 0.8F);
		}
	}

	/**
	 * One tentacle as a chain of 8-sided tapered tubes from the anchor toward "end" (end is relative to the camera,
	 * which is at the origin). reach 0..1 controls how far along that line the tip has got; coil wraps the last stretch
	 * in a spiral around the line, which is how it ends up wrapped around the player.
	 */
	private static void drawTentacle(Matrix4f m, float radius, Vector3f anchor, Vector3f end, float reach, float coil,
			float time, long seed, float thickness, float alpha) {
		if (reach <= 0.001F) {
			return;
		}
		Vector3f tip = new Vector3f(anchor).lerp(end, reach);
		Vector3f axis = new Vector3f(tip).sub(anchor);
		float length = axis.length();
		if (length < 0.01F) {
			return;
		}
		Vector3f dir = new Vector3f(axis).div(length);
		Vector3f ref = Math.abs(dir.y) > 0.9F ? new Vector3f(1.0F, 0.0F, 0.0F) : new Vector3f(0.0F, 1.0F, 0.0F);
		Vector3f perpA = new Vector3f(dir).cross(ref).normalize();
		Vector3f perpB = new Vector3f(dir).cross(perpA).normalize();
		Random rnd = new Random(seed);
		float phase1 = rnd.nextFloat() * Mth.TWO_PI;
		float phase2 = rnd.nextFloat() * Mth.TWO_PI;
		float taut = 1.0F - 0.65F * RenderUtil.smooth(0.6F, 1.0F, reach);

		Vector3f[] centers = new Vector3f[SEGMENTS + 1];
		float[] radii = new float[SEGMENTS + 1];
		float baseRadius = radius * 0.045F * thickness;
		float tipRadius = 0.18F * thickness + 0.1F;
		for (int i = 0; i <= SEGMENTS; i++) {
			float u = i / (float) SEGMENTS;
			Vector3f c = new Vector3f(anchor).fma(u, axis);
			float envelope = (float) Math.pow(Math.max(0.0F, Mth.sin(u * Mth.PI)), 0.8D);
			float wig = 0.07F * length * envelope * taut;
			float w1 = Mth.sin(u * 7.0F - time * 0.11F + phase1) * wig;
			float w2 = Mth.cos(u * 5.0F - time * 0.09F + phase2) * wig;
			c.fma(w1, perpA).fma(w2, perpB);
			if (coil > 0.0F) {
				// spiral hugging the line, tightening as it nears the player
				float k = RenderUtil.smooth(0.55F, 1.0F, u);
				float spiral = u * 34.0F + time * 0.05F;
				float coilRadius = coil * k * k * (1.1F + 0.5F * (1.0F - u));
				c.fma(Mth.cos(spiral) * coilRadius, perpA).fma(Mth.sin(spiral) * coilRadius, perpB);
			}
			centers[i] = c;
			radii[i] = Mth.lerp((float) Math.pow(u, 0.75D), baseRadius, tipRadius) * (0.92F + 0.08F * Mth.sin(time * 0.2F + u * 9.0F));
		}

		RenderSystem.depthMask(true);
		BufferBuilder b = RenderUtil.begin(TENTACLE);
		Vector3f t0 = new Vector3f();
		Vector3f n1 = new Vector3f();
		Vector3f n2 = new Vector3f();
		Vector3f[] ringA = new Vector3f[SIDES + 1];
		Vector3f[] ringB = new Vector3f[SIDES + 1];
		float[] shadeA = new float[SIDES + 1];
		float[] shadeB = new float[SIDES + 1];
		for (int j = 0; j <= SIDES; j++) {
			ringA[j] = new Vector3f();
			ringB[j] = new Vector3f();
		}
		int ia = RenderUtil.a255(alpha);
		for (int i = 0; i < SEGMENTS; i++) {
			ring(centers, radii, i, t0, n1, n2, ringA, shadeA);
			ring(centers, radii, i + 1, t0, n1, n2, ringB, shadeB);
			float v0 = i / (float) SEGMENTS * 16.0F;
			float v1 = (i + 1) / (float) SEGMENTS * 16.0F;
			for (int j = 0; j < SIDES; j++) {
				float u0 = j / (float) SIDES * 2.0F;
				float u1 = (j + 1) / (float) SIDES * 2.0F;
				int c0 = RenderUtil.a255(shadeA[j]);
				int c1 = RenderUtil.a255(shadeA[j + 1]);
				int c2 = RenderUtil.a255(shadeB[j + 1]);
				int c3 = RenderUtil.a255(shadeB[j]);
				RenderUtil.vertex(b, m, ringA[j].x, ringA[j].y, ringA[j].z, u0, v0, c0, c0, c0, ia);
				RenderUtil.vertex(b, m, ringA[j + 1].x, ringA[j + 1].y, ringA[j + 1].z, u1, v0, c1, c1, c1, ia);
				RenderUtil.vertex(b, m, ringB[j + 1].x, ringB[j + 1].y, ringB[j + 1].z, u1, v1, c2, c2, c2, ia);
				RenderUtil.vertex(b, m, ringB[j].x, ringB[j].y, ringB[j].z, u0, v1, c3, c3, c3, ia);
			}
		}
		RenderUtil.end(b);
		RenderSystem.depthMask(false);
	}

	/** Fills {@code out} with the ring of vertices around centers[i], and a rough per-vertex brightness. */
	private static void ring(Vector3f[] centers, float[] radii, int i, Vector3f tangent, Vector3f n1, Vector3f n2,
			Vector3f[] out, float[] shade) {
		int prev = Math.max(0, i - 1);
		int next = Math.min(centers.length - 1, i + 1);
		tangent.set(centers[next]).sub(centers[prev]);
		if (tangent.lengthSquared() < 1.0E-6F) {
			tangent.set(0.0F, 1.0F, 0.0F);
		}
		tangent.normalize();
		Vector3f ref = Math.abs(tangent.y) > 0.9F ? new Vector3f(1.0F, 0.0F, 0.0F) : new Vector3f(0.0F, 1.0F, 0.0F);
		n1.set(tangent).cross(ref).normalize();
		n2.set(tangent).cross(n1).normalize();
		for (int j = 0; j <= SIDES; j++) {
			float a = Mth.TWO_PI * j / SIDES;
			float cs = Mth.cos(a);
			float sn = Mth.sin(a);
			float nx = n1.x * cs + n2.x * sn;
			float ny = n1.y * cs + n2.y * sn;
			float nz = n1.z * cs + n2.z * sn;
			out[j].set(centers[i]).add(nx * radii[i], ny * radii[i], nz * radii[i]);
			shade[j] = Mth.clamp(0.55F + 0.45F * (nx * 0.3F + ny * 0.8F + nz * 0.5F), 0.25F, 1.0F);
		}
	}

	// ------------------------------------------------------------------------------------ shards
	private static void renderShards(Matrix4f m, float radius, float t, long seed, Vector3f crackDir) {
		Random rnd = new Random(seed ^ 0x5DEECE66DL);
		Vector3f origin = new Vector3f(crackDir).mul(radius * 0.86F);
		Quaternionf q = new Quaternionf();
		Vector3f v = new Vector3f();
		float[] ang = new float[4];
		float[] rad = new float[4];
		BufferBuilder b = RenderUtil.begin(SHARD);
		for (int i = 0; i < SHARDS; i++) {
			// every random draw happens for every shard, in the same order, whether or not it is visible yet
			float delay = rnd.nextFloat() * 6.0F;
			float dur = 24.0F + rnd.nextFloat() * 40.0F;
			float tx = (rnd.nextFloat() - 0.5F) * 2.0F * radius * 0.45F;
			float ty = (rnd.nextFloat() * 0.6F - 0.1F) * radius;
			float tz = (rnd.nextFloat() - 0.5F) * 2.0F * radius * 0.45F;
			float jx = (rnd.nextFloat() - 0.5F) * radius * 0.08F;
			float jy = (rnd.nextFloat() - 0.5F) * radius * 0.08F;
			float jz = (rnd.nextFloat() - 0.5F) * radius * 0.08F;
			float size = 0.9F + rnd.nextFloat() * 2.6F;
			float ax = rnd.nextFloat() - 0.5F;
			float ay = rnd.nextFloat() - 0.5F;
			float az = rnd.nextFloat() - 0.5F;
			float spin = (rnd.nextFloat() - 0.5F) * 0.35F;
			float angle0 = rnd.nextFloat() * Mth.TWO_PI;
			for (int k = 0; k < 4; k++) {
				ang[k] = Mth.HALF_PI * k + (rnd.nextFloat() - 0.5F) * 0.7F;
				rad[k] = 0.4F + rnd.nextFloat() * 0.6F;
			}
			float tau = t - FractureTimeline.CRACK - delay;
			if (tau < 0.0F) {
				continue;
			}
			float flight = Mth.clamp(tau / dur, 0.0F, 1.0F);
			float ease = 1.0F - (1.0F - flight) * (1.0F - flight);
			float x = Mth.lerp(ease, origin.x + jx, tx);
			float y = Mth.lerp(ease, origin.y + jy, ty);
			float z = Mth.lerp(ease, origin.z + jz, tz);
			float fall = Math.max(0.0F, tau - dur);
			y -= 0.012F * fall * fall;
			float life = Mth.clamp(1.0F - (tau - 150.0F) / 60.0F, 0.0F, 1.0F);
			if (life <= 0.0F) {
				continue;
			}
			float dist = Mth.sqrt(x * x + y * y + z * z);
			float scale = size * (0.6F + 1.4F * Mth.clamp(dist / (0.6F * radius), 0.0F, 1.0F));
			Vector3f axis = new Vector3f(ax, ay, az);
			if (axis.lengthSquared() < 1.0E-4F) {
				axis.set(0.0F, 1.0F, 0.0F);
			}
			axis.normalize();
			q.identity().rotateAxis(angle0 + spin * tau, axis.x, axis.y, axis.z);
			int a = RenderUtil.a255(0.85F * life);
			for (int c = 0; c < 4; c++) {
				v.set(Mth.cos(ang[c]) * rad[c] * scale, Mth.sin(ang[c]) * rad[c] * scale, 0.0F);
				q.transform(v);
				float u = (c == 1 || c == 2) ? 1.0F : 0.0F;
				float vv = (c >= 2) ? 1.0F : 0.0F;
				RenderUtil.vertex(b, m, x + v.x, y + v.y, z + v.z, u, vv, 225, 240, 255, a);
			}
		}
		RenderUtil.end(b);
	}
}
