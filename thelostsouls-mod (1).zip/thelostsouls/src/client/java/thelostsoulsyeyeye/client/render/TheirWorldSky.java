package thelostsoulsyeyeye.client.render;

import java.util.Random;

import org.joml.Matrix4f;
import org.joml.Vector3f;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import thelostsoulsyeyeye.Thelostsouls;
import thelostsoulsyeyeye.client.ClientFractureState;

/**
 * The sky of Their World: it replaces the vanilla sky completely, and nothing about it is quite real.
 * A sickly gradient that breathes, two counter-rotating marbled layers, the cracks we saw from the other
 * side, a black sun that never sets, an Eye twice the size it was before, and stars that flicker like dead pixels.
 */
public final class TheirWorldSky {
	private TheirWorldSky() {}

	private static final ResourceLocation SWIRL = Thelostsouls.id("textures/environment/sky_swirl.png");
	private static final ResourceLocation CRACKS = Thelostsouls.id("textures/environment/sky_cracks.png");
	private static final ResourceLocation VOID = Thelostsouls.id("textures/environment/sky_void.png");
	private static final ResourceLocation DARK_SUN = Thelostsouls.id("textures/environment/dark_sun.png");

	private static final Vector3f UP = new Vector3f(0.0F, 1.0F, 0.0F);
	private static final Vector3f DARK_SUN_DIR = new Vector3f(0.6F, 0.22F, 0.75F).normalize();

	// stars: fixed positions, generated once
	private static final int STARS = 150;
	private static final float[][] STAR_DATA = new float[STARS][5]; // x, y, z, size, phase

	static {
		Random rnd = new Random(77L);
		for (int i = 0; i < STARS; i++) {
			float y = 0.03F + rnd.nextFloat() * 0.97F;
			float angle = rnd.nextFloat() * Mth.TWO_PI;
			float horizontal = Mth.sqrt(1.0F - y * y);
			STAR_DATA[i][0] = Mth.cos(angle) * horizontal;
			STAR_DATA[i][1] = y;
			STAR_DATA[i][2] = Mth.sin(angle) * horizontal;
			STAR_DATA[i][3] = 0.004F + rnd.nextFloat() * 0.010F;
			STAR_DATA[i][4] = rnd.nextFloat() * Mth.TWO_PI;
		}
	}

	public static void render(WorldRenderContext context) {
		ClientLevel level = context.world();
		if (level == null) {
			return;
		}
		float time = level.getGameTime() + context.tickDelta();
		float radius = 100.0F;
		Matrix4f m = context.matrixStack().last().pose();

		RenderUtil.begin3D();
		RenderSystem.disableDepthTest();

		// 1. the breathing gradient
		float pulse = 0.5F + 0.5F * Mth.sin(time * 0.02F);
		float[] top = {0.07F + 0.04F * pulse, 0.0F, 0.10F + 0.05F * pulse};
		float[] horizon = {0.36F + 0.10F * Mth.sin(time * 0.011F), 0.07F, 0.05F + 0.05F * Mth.cos(time * 0.017F)};
		BufferBuilder b = RenderUtil.begin(RenderUtil.SOLID);
		RenderUtil.gradientDome(b, m, radius, 1.95F, 12, 32, top, horizon, 1.0F, 1.4F);
		RenderUtil.end(b);

		// 2. two slowly counter-rotating marbled layers
		b = RenderUtil.begin(SWIRL);
		RenderUtil.cap(b, m, UP, radius * 0.99F, 1.75F, 10, 32, time * 0.0007F, 255, 255, 255, RenderUtil.a255(0.55F), 0.0F);
		RenderUtil.end(b);
		b = RenderUtil.begin(SWIRL);
		RenderUtil.cap(b, m, UP, radius * 0.98F, 1.2F, 8, 28, -time * 0.0011F, 255, 200, 255, RenderUtil.a255(0.35F), 0.0F);
		RenderUtil.end(b);

		// 3. the cracks, seen from the inside, flickering as if something behind them is moving
		float crackPulse = 0.75F + 0.25F * Mth.sin(time * 0.07F);
		b = RenderUtil.begin(CRACKS);
		RenderUtil.cap(b, m, ClientFractureState.CRACK_DIR, radius * 0.97F, 1.75F, 14, 36, 0.0F, 255, 255, 255, RenderUtil.a255(0.9F * crackPulse), 0.0F);
		RenderUtil.end(b);
		b = RenderUtil.begin(VOID);
		RenderUtil.billboard(b, m, ClientFractureState.CRACK_DIR, radius * 0.96F, 0.34F, 0.34F, 0.0F, 0.0F, 255, 255, 255, 235);
		RenderUtil.end(b);

		// 4. the black sun, which never moves
		b = RenderUtil.begin(DARK_SUN);
		RenderUtil.billboard(b, m, DARK_SUN_DIR, radius * 0.95F, 0.7F, 0.7F, 0.0F, 0.0F, 255, 230, 255, 255);
		RenderUtil.end(b);

		// 5. the Eye
		SkyEffects.drawEye(m, radius, context.camera().getLookVector(), time, 1.0F, 1.5F);

		// 6. stars that flicker like dead pixels
		b = RenderUtil.begin(RenderUtil.SOLID);
		Vector3f dir = new Vector3f();
		for (int i = 0; i < STARS; i++) {
			float s = Mth.sin(time * 0.12F + STAR_DATA[i][4]);
			float a = (0.2F + 0.8F * s * s) * 0.9F;
			dir.set(STAR_DATA[i][0], STAR_DATA[i][1], STAR_DATA[i][2]);
			RenderUtil.billboard(b, m, dir, radius * 0.94F, STAR_DATA[i][3], STAR_DATA[i][3], 0.0F, 0.0F, 255, 200, 215, RenderUtil.a255(a));
		}
		RenderUtil.end(b);

		RenderUtil.end3D();
	}
}
