package thelostsoulsyeyeye.client.render;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.EyesLayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;

/** Draws a second, fullbright, additive pass of the creature with a texture where only the glowing bits are lit. */
public class GlowLayer<T extends Entity, M extends EntityModel<T>> extends EyesLayer<T, M> {
	private final RenderType renderType;

	public GlowLayer(RenderLayerParent<T, M> parent, ResourceLocation glowTexture) {
		super(parent);
		this.renderType = RenderType.eyes(glowTexture);
	}

	@Override
	public RenderType renderType() {
		return this.renderType;
	}
}
