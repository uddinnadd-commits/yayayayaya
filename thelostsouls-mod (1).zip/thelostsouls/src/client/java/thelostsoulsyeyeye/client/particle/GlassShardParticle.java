package thelostsoulsyeyeye.client.particle;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.SimpleParticleType;

/** A tumbling sliver of broken sky. Falls fast, spins, and fades as it dies. */
public class GlassShardParticle extends TextureSheetParticle {
	private final float spin;

	protected GlassShardParticle(ClientLevel level, double x, double y, double z, double vx, double vy, double vz, SpriteSet sprites) {
		super(level, x, y, z, vx, vy, vz);
		this.pickSprite(sprites);
		this.xd = vx;
		this.yd = vy;
		this.zd = vz;
		this.gravity = 0.35F;
		this.friction = 0.98F;
		this.lifetime = 50 + this.random.nextInt(60);
		this.quadSize = 0.12F + this.random.nextFloat() * 0.26F;
		this.hasPhysics = true;
		this.roll = this.random.nextFloat() * (float) Math.PI * 2.0F;
		this.oRoll = this.roll;
		this.spin = (this.random.nextFloat() - 0.5F) * 0.5F;
	}

	@Override
	public void tick() {
		super.tick();
		this.oRoll = this.roll;
		this.roll += this.spin;
		int fade = 15;
		if (this.age > this.lifetime - fade) {
			this.alpha = Math.max(0.0F, (this.lifetime - this.age) / (float) fade);
		}
	}

	@Override
	public ParticleRenderType getRenderType() {
		return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
	}

	public static class Provider implements ParticleProvider<SimpleParticleType> {
		private final SpriteSet sprites;

		public Provider(SpriteSet sprites) {
			this.sprites = sprites;
		}

		@Override
		public Particle createParticle(SimpleParticleType type, ClientLevel level, double x, double y, double z, double vx, double vy, double vz) {
			return new GlassShardParticle(level, x, y, z, vx, vy, vz, this.sprites);
		}
	}
}
