package thelostsoulsyeyeye.client;

import java.util.List;

import org.joml.Vector3f;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import thelostsoulsyeyeye.client.render.RenderUtil;
import thelostsoulsyeyeye.client.sound.HeartbeatSound;
import thelostsoulsyeyeye.entity.CorruptedEntity;
import thelostsoulsyeyeye.fracture.FractureTimeline;
import thelostsoulsyeyeye.registry.ModParticles;
import thelostsoulsyeyeye.registry.ModSounds;
import thelostsoulsyeyeye.world.TheirWorld;

/**
 * Everything the client knows about the story: how far along the sky is, whether the cinematic is playing
 * (and where in it we are), and the little effects that follow from that (ambient sounds, camera shake,
 * falling shards, the heartbeat when Them are near). Rendering reads from here; it never mutates it.
 */
public final class ClientFractureState {
	private ClientFractureState() {}

	/** The wound in the sky. Fixed so the cracks that creep in over time are where the tentacle finally comes from. */
	public static final Vector3f CRACK_DIR = new Vector3f(0.55F, 0.62F, -0.56F).normalize();
	/** Where the Eye hangs. */
	public static final Vector3f EYE_DIR = new Vector3f(-0.72F, 0.50F, 0.48F).normalize();

	private static float target;
	private static float progress;
	private static boolean eventActive;
	private static int eventTick;
	private static long eventSeed;
	private static int arriveTicks = -1;
	private static float flicker;
	private static int nextAmbient = 600;
	private static float proximity;
	private static float proximityTarget;
	private static HeartbeatSound heartbeat;

	// ------------------------------------------------------------------ packets (called on the client thread)
	public static void onProgress(float value) {
		target = Mth.clamp(value, 0.0F, 1.0F);
		if (Math.abs(target - progress) > 0.25F) {
			progress = target;
		}
	}

	public static void onFractureStart(long seed) {
		eventActive = true;
		eventTick = 0;
		eventSeed = seed;
		arriveTicks = -1;
	}

	public static void onFractureEnd() {
		eventActive = false;
	}

	public static void onArrive() {
		eventActive = false;
		arriveTicks = 0;
		Minecraft mc = Minecraft.getInstance();
		if (mc.player != null && mc.level != null) {
			mc.level.playLocalSound(mc.player.getX(), mc.player.getY(), mc.player.getZ(), ModSounds.FRACTURE_ARRIVE, SoundSource.MASTER, 1.0F, 1.0F, false);
		}
	}

	// ------------------------------------------------------------------ accessors used by renderers
	public static float progress() {
		return progress;
	}

	public static boolean isEventActive() {
		return eventActive;
	}

	public static float eventTime(float partialTick) {
		return eventTick + partialTick;
	}

	public static long eventSeed() {
		return eventSeed;
	}

	public static float flicker() {
		return flicker;
	}

	public static float proximity() {
		return proximity;
	}

	/** 0..1 white flash at the moment the sky breaks. */
	public static float flashAlpha(float partialTick) {
		if (!eventActive) {
			return 0.0F;
		}
		float t = eventTick + partialTick - FractureTimeline.CRACK;
		return t < 0.0F ? 0.0F : Mth.clamp(1.0F - t / 14.0F, 0.0F, 1.0F);
	}

	/** 0..1 black overlay: fade-out before the teleport, fade-in after arriving. */
	public static float blackAlpha(float partialTick) {
		if (arriveTicks >= 0) {
			return Mth.clamp(1.0F - (arriveTicks + partialTick) / 100.0F, 0.0F, 1.0F);
		}
		if (eventActive) {
			float t = eventTick + partialTick;
			if (t >= FractureTimeline.FADE_START) {
				return Mth.clamp((t - FractureTimeline.FADE_START) / (FractureTimeline.TELEPORT - FractureTimeline.FADE_START + 10.0F), 0.0F, 1.0F);
			}
		}
		return 0.0F;
	}

	/** 0..1 sickly red pulse while the tentacle has hold of you. */
	public static float gripAlpha(float partialTick) {
		if (!eventActive) {
			return 0.0F;
		}
		float t = eventTick + partialTick;
		if (t < FractureTimeline.PULL) {
			return 0.0F;
		}
		return 0.28F * (0.6F + 0.4F * Mth.sin(t * 0.5F)) * RenderUtil.smooth(FractureTimeline.PULL, FractureTimeline.PULL + 20, t);
	}

	// ------------------------------------------------------------------ per-tick driver
	public static void tick(Minecraft mc) {
		if (mc.level == null || mc.player == null) {
			eventActive = false;
			arriveTicks = -1;
			proximity = 0.0F;
			heartbeat = null;
			progress = 0.0F;
			target = 0.0F;
			return;
		}
		progress += (target - progress) * 0.08F;
		flicker = Math.max(0.0F, flicker - 0.07F);
		if (arriveTicks >= 0 && ++arriveTicks > 140) {
			arriveTicks = -1;
		}

		ClientLevel level = mc.level;
		LocalPlayer player = mc.player;
		if (eventActive) {
			eventTick++;
			tickEvent(mc, level, player);
			if (eventTick > FractureTimeline.TELEPORT + 200) {
				eventActive = false;
			}
		} else if (level.dimension() == Level.OVERWORLD) {
			tickAmbient(level, player);
		}
		tickProximity(mc, level, player);
	}

	private static void play(ClientLevel level, LocalPlayer player, SoundEvent sound, float volume, float pitch) {
		level.playLocalSound(player.getX(), player.getY(), player.getZ(), sound, SoundSource.MASTER, volume, pitch, false);
	}

	private static void tickEvent(Minecraft mc, ClientLevel level, LocalPlayer player) {
		int t = eventTick;
		RandomSource random = level.getRandom();
		if (t == FractureTimeline.RUMBLE) {
			play(level, player, ModSounds.FRACTURE_RUMBLE, 1.0F, 1.0F);
		} else if (t == FractureTimeline.CRACK) {
			play(level, player, ModSounds.FRACTURE_CRACK, 1.0F, 1.0F);
			play(level, player, ModSounds.FRACTURE_GLASS, 0.9F, 1.0F);
		} else if (t == FractureTimeline.SLITHER) {
			play(level, player, ModSounds.FRACTURE_SLITHER, 0.9F, 1.0F);
		} else if (t == FractureTimeline.ROAR) {
			play(level, player, ModSounds.FRACTURE_ROAR, 1.0F, 1.0F);
		} else if (t == FractureTimeline.PULL) {
			play(level, player, ModSounds.FRACTURE_PULL, 1.0F, 1.0F);
		}

		// the world shakes: a hairline tremor, a violent jolt at the crack, then a constant shudder
		float amp;
		if (t < FractureTimeline.CRACK) {
			amp = 0.25F * t / FractureTimeline.CRACK;
		} else if (t < FractureTimeline.CRACK + 25) {
			amp = 3.0F * (1.0F - (t - FractureTimeline.CRACK) / 25.0F) + 0.5F;
		} else {
			amp = 0.5F;
		}
		player.setXRot(player.getXRot() + (random.nextFloat() - 0.5F) * amp);
		player.setYRot(player.getYRot() + (random.nextFloat() - 0.5F) * amp);

		// and then your head is turned to look at what is coming for you
		if (t >= FractureTimeline.LOOK_UP && t < FractureTimeline.TELEPORT) {
			player.setXRot(player.getXRot() + (-58.0F - player.getXRot()) * 0.06F);
		}

		// glass rains down all around you
		if (t >= FractureTimeline.CRACK && t < FractureTimeline.FADE_START) {
			int count = t < FractureTimeline.CRACK + 30 ? 6 : 2;
			for (int i = 0; i < count; i++) {
				double x = player.getX() + (random.nextDouble() - 0.5D) * 30.0D;
				double y = player.getY() + 6.0D + random.nextDouble() * 14.0D;
				double z = player.getZ() + (random.nextDouble() - 0.5D) * 30.0D;
				level.addParticle(ModParticles.GLASS_SHARD, x, y, z, (random.nextDouble() - 0.5D) * 0.12D, -0.1D - random.nextDouble() * 0.2D, (random.nextDouble() - 0.5D) * 0.12D);
			}
		}
	}

	private static void tickAmbient(ClientLevel level, LocalPlayer player) {
		float p = progress;
		if (p < 0.2F) {
			return;
		}
		RandomSource random = level.getRandom();
		if (p > 0.6F && random.nextInt(260) == 0) {
			flicker = 0.55F;
		}
		if (--nextAmbient > 0) {
			return;
		}
		SoundEvent sound;
		float roll = random.nextFloat();
		if (p < 0.45F) {
			sound = ModSounds.AMBIENT_SKY_CREAK;
		} else if (p < 0.8F) {
			sound = roll < 0.5F ? ModSounds.AMBIENT_SKY_CREAK : ModSounds.AMBIENT_SKY_WHISPER;
		} else {
			sound = roll < 0.5F ? ModSounds.AMBIENT_SKY_WHISPER : roll < 0.8F ? ModSounds.AMBIENT_SKY_CREAK : ModSounds.AMBIENT_SKY_SCREAM;
		}
		double angle = random.nextDouble() * Math.PI * 2.0D;
		double dist = 6.0D + random.nextDouble() * 8.0D;
		level.playLocalSound(player.getX() + Math.cos(angle) * dist, player.getY() + 2.0D, player.getZ() + Math.sin(angle) * dist,
				sound, SoundSource.AMBIENT, 0.4F + 0.5F * p, 0.9F + random.nextFloat() * 0.2F, false);
		nextAmbient = (int) (Mth.lerp(p, 1800.0F, 300.0F) * (0.6F + random.nextFloat() * 0.8F));
	}

	private static void tickProximity(Minecraft mc, ClientLevel level, LocalPlayer player) {
		float wanted = 0.0F;
		if (level.dimension() == TheirWorld.LEVEL_KEY && player.tickCount % 4 == 0) {
			List<CorruptedEntity> near = level.getEntitiesOfClass(CorruptedEntity.class, player.getBoundingBox().inflate(30.0D), CorruptedEntity::isThem);
			double best = Double.MAX_VALUE;
			for (CorruptedEntity e : near) {
				best = Math.min(best, e.distanceToSqr(player));
			}
			if (best < Double.MAX_VALUE) {
				// the search box is a cube, so a creature in a corner can be >30 blocks away: clamp, or pow() of a negative gives NaN
				double closeness = Math.max(0.0D, 1.0D - Math.sqrt(best) / 30.0D);
				wanted = (float) Math.pow(closeness, 1.3D);
			}
			proximityTarget = wanted;
		}
		proximity += (proximityTarget - proximity) * 0.12F;
		if (level.dimension() != TheirWorld.LEVEL_KEY) {
			proximityTarget = 0.0F;
		}
		if (proximity > 0.12F && (heartbeat == null || !mc.getSoundManager().isActive(heartbeat))) {
			heartbeat = new HeartbeatSound();
			mc.getSoundManager().play(heartbeat);
		}
	}
}
