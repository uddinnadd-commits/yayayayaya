package thelostsoulsyeyeye.block;

import java.util.List;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.storage.loot.LootParams;
import net.minecraft.world.level.storage.loot.LootTable;
import net.minecraft.world.level.storage.loot.parameters.LootContextParamSets;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import thelostsoulsyeyeye.Thelostsouls;
import thelostsoulsyeyeye.entity.CorruptedEntity;
import thelostsoulsyeyeye.fracture.ModAdvancements;
import thelostsoulsyeyeye.registry.ModSounds;

/**
 * The reward at the end of a Memory Vault. It refuses to open while any monster spawner or living
 * guardian is still within the dungeon, so "completing" the dungeon means breaking its spawners and
 * killing what they spawned. When it opens it rolls data/thelostsouls/loot_tables/chests/memory_vault.json.
 */
public class MemoryCacheBlock extends Block {
	public static final BooleanProperty OPENED = BooleanProperty.create("opened");
	private static final ResourceLocation LOOT = Thelostsouls.id("chests/memory_vault");
	private static final int SCAN_RADIUS = 28;

	public MemoryCacheBlock(Properties properties) {
		super(properties);
		this.registerDefaultState(this.stateDefinition.any().setValue(OPENED, false));
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		builder.add(OPENED);
	}

	@Override
	public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
		if (level.isClientSide) {
			return InteractionResult.SUCCESS;
		}
		if (state.getValue(OPENED)) {
			player.displayClientMessage(Component.translatable("message.thelostsouls.cache_empty"), true);
			return InteractionResult.CONSUME;
		}
		ServerLevel server = (ServerLevel) level;
		int guards = countGuardians(server, pos);
		if (guards > 0) {
			player.displayClientMessage(Component.translatable("message.thelostsouls.cache_guarded", guards), true);
			server.playSound(null, pos, ModSounds.BLOCK_MEMORY_CACHE_DENY, SoundSource.BLOCKS, 1.0F, 1.0F);
			return InteractionResult.CONSUME;
		}
		open(server, pos, state, player);
		return InteractionResult.CONSUME;
	}

	private static int countGuardians(ServerLevel level, BlockPos pos) {
		int count = 0;
		BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
		for (int x = -SCAN_RADIUS; x <= SCAN_RADIUS; x++) {
			for (int y = -8; y <= 8; y++) {
				for (int z = -SCAN_RADIUS; z <= SCAN_RADIUS; z++) {
					m.set(pos.getX() + x, pos.getY() + y, pos.getZ() + z);
					if (level.getBlockState(m).is(Blocks.SPAWNER)) {
						count++;
					}
				}
			}
		}
		AABB box = new AABB(pos).inflate(SCAN_RADIUS, 10, SCAN_RADIUS);
		count += level.getEntitiesOfClass(CorruptedEntity.class, box, e -> !e.isThem() && e.isAlive()).size();
		return count;
	}

	private static void open(ServerLevel level, BlockPos pos, BlockState state, Player player) {
		level.setBlock(pos, state.setValue(OPENED, true), 3);
		LootTable table = level.getServer().getLootData().getLootTable(LOOT);
		LootParams params = new LootParams.Builder(level)
				.withParameter(LootContextParams.ORIGIN, Vec3.atCenterOf(pos))
				.withOptionalParameter(LootContextParams.THIS_ENTITY, player)
				.withLuck(player.getLuck())
				.create(LootContextParamSets.CHEST);
		List<ItemStack> loot = table.getRandomItems(params);
		for (ItemStack stack : loot) {
			Block.popResource(level, pos.above(), stack);
		}
		ExperienceOrb.award(level, Vec3.atCenterOf(pos), 60);
		level.playSound(null, pos, ModSounds.BLOCK_MEMORY_CACHE_OPEN, SoundSource.BLOCKS, 1.0F, 1.0F);
		level.sendParticles(ParticleTypes.SOUL, pos.getX() + 0.5D, pos.getY() + 1.0D, pos.getZ() + 0.5D, 40, 0.5D, 0.6D, 0.5D, 0.04D);
		if (player instanceof ServerPlayer serverPlayer) {
			ModAdvancements.award(serverPlayer, "memory_vault");
		}
	}
}
