package thelostsoulsyeyeye.net;

import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import thelostsoulsyeyeye.Thelostsouls;

/** Server -> client messages. (Nothing travels the other way: the server is always the authority.) */
public final class ModNetworking {
	private ModNetworking() {}

	/** float progress 0..1 toward the fracture; drives how wrong the Overworld sky looks. */
	public static final ResourceLocation PROGRESS = Thelostsouls.id("progress");
	/** long seed; the cinematic begins (tentacle, shards, pull). */
	public static final ResourceLocation FRACTURE_START = Thelostsouls.id("fracture_start");
	/** the cinematic was aborted (death, dimension change). */
	public static final ResourceLocation FRACTURE_END = Thelostsouls.id("fracture_end");
	/** the player just arrived in Their World; fade in from black. */
	public static final ResourceLocation ARRIVE = Thelostsouls.id("arrive");

	public static void sendProgress(ServerPlayer player, float progress) {
		FriendlyByteBuf buf = PacketByteBufs.create();
		buf.writeFloat(progress);
		ServerPlayNetworking.send(player, PROGRESS, buf);
	}

	public static void sendFractureStart(ServerPlayer player, long seed) {
		FriendlyByteBuf buf = PacketByteBufs.create();
		buf.writeLong(seed);
		ServerPlayNetworking.send(player, FRACTURE_START, buf);
	}

	public static void sendFractureEnd(ServerPlayer player) {
		ServerPlayNetworking.send(player, FRACTURE_END, PacketByteBufs.create());
	}

	public static void sendArrive(ServerPlayer player) {
		ServerPlayNetworking.send(player, ARRIVE, PacketByteBufs.create());
	}
}
