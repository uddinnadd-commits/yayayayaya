package thelostsoulsyeyeye.registry;

import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.SpawnEggItem;
import thelostsoulsyeyeye.Thelostsouls;
import thelostsoulsyeyeye.item.LoreItem;
import thelostsoulsyeyeye.item.ShardTier;
import thelostsoulsyeyeye.item.ShardbladeItem;

public final class ModItems {
	private ModItems() {}

	public static final Item SKY_SHARD = register("sky_shard",
			new LoreItem(new Item.Properties().rarity(Rarity.UNCOMMON), "item.thelostsouls.sky_shard.lore"));
	public static final Item MEMORY_FRAGMENT = register("memory_fragment",
			new LoreItem(new Item.Properties().rarity(Rarity.RARE), "item.thelostsouls.memory_fragment.lore"));
	public static final Item SHARDBLADE = register("shardblade",
			new ShardbladeItem(ShardTier.INSTANCE, 3, -2.3F, new Item.Properties().rarity(Rarity.RARE)));

	public static final Item MEMORY_CACHE = register("memory_cache",
			new BlockItem(ModBlocks.MEMORY_CACHE, new Item.Properties().rarity(Rarity.EPIC)));

	public static final Item HOLLOW_WALKER_SPAWN_EGG = register("hollow_walker_spawn_egg",
			new SpawnEggItem(ModEntities.HOLLOW_WALKER, 0x6E6A72, 0x761014, new Item.Properties()));
	public static final Item CRAWLER_SPAWN_EGG = register("crawler_spawn_egg",
			new SpawnEggItem(ModEntities.CRAWLER, 0x5C5E64, 0xD6D2C8, new Item.Properties()));
	public static final Item STRETCHED_SPAWN_EGG = register("stretched_spawn_egg",
			new SpawnEggItem(ModEntities.STRETCHED, 0xD0CBC6, 0x6E0A0A, new Item.Properties()));
	public static final Item ECHO_HOUND_SPAWN_EGG = register("echo_hound_spawn_egg",
			new SpawnEggItem(ModEntities.ECHO_HOUND, 0x181A24, 0x6EE6FF, new Item.Properties()));
	public static final Item REMNANT_SPAWN_EGG = register("remnant_spawn_egg",
			new SpawnEggItem(ModEntities.REMNANT, 0x464C5A, 0x6EE1FF, new Item.Properties()));

	public static final CreativeModeTab TAB = FabricItemGroup.builder()
			.title(Component.translatable("itemGroup.thelostsouls"))
			.icon(() -> new ItemStack(SKY_SHARD))
			.displayItems((parameters, output) -> {
				output.accept(SKY_SHARD);
				output.accept(MEMORY_FRAGMENT);
				output.accept(SHARDBLADE);
				output.accept(MEMORY_CACHE);
				output.accept(HOLLOW_WALKER_SPAWN_EGG);
				output.accept(CRAWLER_SPAWN_EGG);
				output.accept(STRETCHED_SPAWN_EGG);
				output.accept(ECHO_HOUND_SPAWN_EGG);
				output.accept(REMNANT_SPAWN_EGG);
			})
			.build();

	private static <T extends Item> T register(String name, T item) {
		return Registry.register(BuiltInRegistries.ITEM, Thelostsouls.id(name), item);
	}

	public static void init() {
		Registry.register(BuiltInRegistries.CREATIVE_MODE_TAB, Thelostsouls.id("main"), TAB);
	}
}
