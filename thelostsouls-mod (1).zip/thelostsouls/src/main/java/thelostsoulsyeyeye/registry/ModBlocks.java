package thelostsoulsyeyeye.registry;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import thelostsoulsyeyeye.Thelostsouls;
import thelostsoulsyeyeye.block.MemoryCacheBlock;

public final class ModBlocks {
	private ModBlocks() {}

	/** The reward chest at the end of a Memory Vault. Unbreakable in survival; opens once the vault is cleared. */
	public static final Block MEMORY_CACHE = Registry.register(BuiltInRegistries.BLOCK, Thelostsouls.id("memory_cache"),
			new MemoryCacheBlock(BlockBehaviour.Properties.of()
					.mapColor(MapColor.COLOR_BLACK)
					.strength(-1.0F, 3600000.0F)
					.sound(SoundType.DEEPSLATE)
					.lightLevel(state -> state.getValue(MemoryCacheBlock.OPENED) ? 2 : 9)));

	public static void init() {}
}
