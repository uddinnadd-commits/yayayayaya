package thelostsoulsyeyeye.world.feature;

import net.minecraft.core.Direction;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LanternBlock;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.StairBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Half;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

/**
 * Memory of waiting: rows of benches all facing a grand gate that is only a painted wall.
 * "NOW BOARDING: THE PALACE". This is where the souls sat while the sky watched.
 */
public class WaitingHallFeature extends Feature<NoneFeatureConfiguration> {
	public WaitingHallFeature() {
		super(NoneFeatureConfiguration.CODEC);
	}

	@Override
	public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> context) {
		StructureBuilder b = new StructureBuilder(context.level(), context.origin(), context.random());
		if (!b.groundOk(-8, -7, 8, 7, 3)) {
			return false;
		}
		b.terraform(-8, -7, 8, 7, 12);
		b.clear(-7, 0, -6, 7, 8, 6);

		// floor
		for (int x = -7; x <= 7; x++) {
			for (int z = -6; z <= 6; z++) {
				b.set(x, -1, z, b.pick(Blocks.POLISHED_DEEPSLATE, Blocks.DEEPSLATE_TILES, Blocks.CRACKED_DEEPSLATE_TILES, Blocks.COBBLED_DEEPSLATE));
			}
		}
		// walls
		for (int y = 0; y <= 5; y++) {
			float decay = 0.05F + 0.04F * y;
			for (int x = -7; x <= 7; x++) {
				for (int z = -6; z <= 6; z++) {
					if ((Math.abs(x) == 7 || Math.abs(z) == 6) && !b.chance(decay)) {
						b.set(x, y, z, b.pick(Blocks.STONE_BRICKS, Blocks.MOSSY_STONE_BRICKS, Blocks.CRACKED_STONE_BRICKS));
					}
				}
			}
		}
		// tall windows down both long walls
		for (int z : new int[]{-3, 0, 3}) {
			for (int y = 2; y <= 4; y++) {
				for (int sx : new int[]{-7, 7}) {
					if (b.chance(0.65F)) {
						b.set(sx, y, z, Blocks.IRON_BARS);
					} else {
						b.clear(sx, y, z, sx, y, z);
					}
				}
			}
		}
		// the entrance
		b.clear(-1, 0, -6, 1, 3, -6);
		// roof: beams and a half-collapsed deck
		BlockState beam = Blocks.DARK_OAK_LOG.defaultBlockState().setValue(RotatedPillarBlock.AXIS, Direction.Axis.X);
		for (int z : new int[]{-4, -1, 2, 5}) {
			for (int x = -6; x <= 6; x++) {
				if (b.chance(0.85F)) {
					b.set(x, 5, z, beam);
				}
			}
		}
		for (int x = -7; x <= 7; x++) {
			for (int z = -6; z <= 6; z++) {
				if (b.chance(0.5F)) {
					b.set(x, 6, z, Blocks.STONE_BRICK_SLAB);
				}
			}
		}

		// benches, all facing the gate (+z). The back of each bench is on its -z side.
		BlockState bench = Blocks.DARK_OAK_STAIRS.defaultBlockState().setValue(StairBlock.FACING, Direction.NORTH).setValue(StairBlock.HALF, Half.BOTTOM);
		for (int z : new int[]{-3, -1, 1, 3}) {
			for (int x = -6; x <= 6; x++) {
				if (Math.abs(x) <= 1) {
					continue;
				}
				if (b.chance(0.82F)) {
					b.set(x, 0, z, bench);
					if (b.chance(0.12F)) {
						b.set(x, 1, z, Blocks.SKELETON_SKULL);
					}
				}
			}
		}
		// aisle carpet, stained
		for (int z = -5; z <= 4; z++) {
			if (b.chance(0.85F)) {
				b.set(0, 0, z, b.chance(0.7F) ? Blocks.RED_CARPET : Blocks.BLACK_CARPET);
			}
		}

		// THE GATE: an impressive frame around a flat black wall
		for (int y = 0; y <= 5; y++) {
			b.set(-2, y, 6, Blocks.QUARTZ_PILLAR);
			b.set(2, y, 6, Blocks.QUARTZ_PILLAR);
		}
		for (int x = -2; x <= 2; x++) {
			b.set(x, 5, 6, Blocks.GILDED_BLACKSTONE);
		}
		b.fill(-1, 0, 6, 1, 4, 6, Blocks.BLACK_CONCRETE);
		b.wallSign(-3, 2, 5, Direction.NORTH, "NOW BOARDING", "THE PALACE", "", "DELAYED");
		b.wallSign(3, 2, 5, Direction.NORTH, "ALL SOULS", "PLEASE WAIT", "", "...");

		// lighting and the register book
		BlockState lantern = Blocks.SOUL_LANTERN.defaultBlockState().setValue(LanternBlock.HANGING, true);
		for (int sx : new int[]{-4, 4}) {
			for (int sz : new int[]{-2, 2}) {
				b.set(sx, 4, sz, lantern);
			}
		}
		b.lectern(0, 0, -5, Direction.NORTH, MemoryLore.book(MemoryLore.WAITING));
		for (int i = 0; i < 8; i++) {
			int x = b.random.nextInt(11) - 5;
			int z = b.random.nextInt(9) - 4;
			if (b.get(x, 4, z).isAir()) {
				b.set(x, 4, z, Blocks.COBWEB);
			}
		}
		return true;
	}
}
