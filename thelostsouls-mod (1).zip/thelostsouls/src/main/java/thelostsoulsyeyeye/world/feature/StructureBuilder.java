package thelostsoulsyeyeye.world.feature;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LecternBlock;
import net.minecraft.world.level.block.WallSignBlock;
import net.minecraft.world.level.block.entity.LecternBlockEntity;
import net.minecraft.world.level.block.entity.SignBlockEntity;
import net.minecraft.world.level.block.entity.SpawnerBlockEntity;
import net.minecraft.world.level.block.entity.SignText;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.block.Rotation;

/**
 * Small toolbox for hand-built structures placed by Features.
 *
 * Structures are described in a local coordinate space (x/z around the origin, y = 0 is the first air
 * block above the ground, so the floor sits at y = -1) and are rotated by a random multiple of 90 degrees.
 * Keep everything within 16 blocks of the origin: that is the area a Feature may safely write to.
 */
public class StructureBuilder {
	public final WorldGenLevel level;
	public final BlockPos origin;
	public final RandomSource random;
	public final Rotation rotation;

	public StructureBuilder(WorldGenLevel level, BlockPos origin, RandomSource random) {
		this.level = level;
		this.origin = origin;
		this.random = random;
		this.rotation = Rotation.getRandom(random);
	}

	public boolean chance(float probability) {
		return this.random.nextFloat() < probability;
	}

	public BlockPos pos(int x, int y, int z) {
		int rx;
		int rz;
		switch (this.rotation) {
			case CLOCKWISE_90 -> {
				rx = -z;
				rz = x;
			}
			case CLOCKWISE_180 -> {
				rx = -x;
				rz = -z;
			}
			case COUNTERCLOCKWISE_90 -> {
				rx = z;
				rz = -x;
			}
			default -> {
				rx = x;
				rz = z;
			}
		}
		return this.origin.offset(rx, y, rz);
	}

	// ------------------------------------------------------------------ blocks
	public void set(int x, int y, int z, BlockState state) {
		this.level.setBlock(pos(x, y, z), state.rotate(this.rotation), 2);
	}

	public void set(int x, int y, int z, Block block) {
		set(x, y, z, block.defaultBlockState());
	}

	public BlockState get(int x, int y, int z) {
		return this.level.getBlockState(pos(x, y, z));
	}

	public void fill(int x1, int y1, int z1, int x2, int y2, int z2, BlockState state) {
		for (int x = Math.min(x1, x2); x <= Math.max(x1, x2); x++) {
			for (int y = Math.min(y1, y2); y <= Math.max(y1, y2); y++) {
				for (int z = Math.min(z1, z2); z <= Math.max(z1, z2); z++) {
					set(x, y, z, state);
				}
			}
		}
	}

	public void fill(int x1, int y1, int z1, int x2, int y2, int z2, Block block) {
		fill(x1, y1, z1, x2, y2, z2, block.defaultBlockState());
	}

	public void clear(int x1, int y1, int z1, int x2, int y2, int z2) {
		fill(x1, y1, z1, x2, y2, z2, Blocks.AIR);
	}

	/** Fills a box, each cell independently picked from the palette. */
	public void fillRandom(int x1, int y1, int z1, int x2, int y2, int z2, Block... palette) {
		for (int x = Math.min(x1, x2); x <= Math.max(x1, x2); x++) {
			for (int y = Math.min(y1, y2); y <= Math.max(y1, y2); y++) {
				for (int z = Math.min(z1, z2); z <= Math.max(z1, z2); z++) {
					set(x, y, z, palette[this.random.nextInt(palette.length)]);
				}
			}
		}
	}

	public Block pick(Block... palette) {
		return palette[this.random.nextInt(palette.length)];
	}

	// ------------------------------------------------------------------ terrain
	public int surfaceHeight(int x, int z) {
		BlockPos p = pos(x, 0, z);
		return this.level.getHeight(Heightmap.Types.WORLD_SURFACE_WG, p.getX(), p.getZ());
	}

	/** True when the ground below the whole rectangle is dirt-ish and its height varies by at most maxSpread. */
	public boolean groundOk(int x1, int z1, int x2, int z2, int maxSpread) {
		int min = Integer.MAX_VALUE;
		int max = Integer.MIN_VALUE;
		int[] xs = {x1, (x1 + x2) / 2, x2};
		int[] zs = {z1, (z1 + z2) / 2, z2};
		for (int x : xs) {
			for (int z : zs) {
				int h = surfaceHeight(x, z);
				min = Math.min(min, h);
				max = Math.max(max, h);
				BlockPos below = pos(x, 0, z);
				if (!this.level.getBlockState(new BlockPos(below.getX(), h - 1, below.getZ())).is(BlockTags.DIRT)) {
					return false;
				}
			}
		}
		return max - min <= maxSpread;
	}

	/** Levels the rectangle to the origin's height: fills dips with dirt and shaves off hills. */
	public void terraform(int x1, int z1, int x2, int z2, int clearHeight) {
		BlockState dirt = Blocks.DIRT.defaultBlockState();
		int floor = this.origin.getY() - 1;
		for (int x = Math.min(x1, x2); x <= Math.max(x1, x2); x++) {
			for (int z = Math.min(z1, z2); z <= Math.max(z1, z2); z++) {
				BlockPos col = pos(x, 0, z);
				int top = this.level.getHeight(Heightmap.Types.WORLD_SURFACE_WG, col.getX(), col.getZ()) - 1;
				for (int y = top + 1; y <= floor; y++) {
					this.level.setBlock(new BlockPos(col.getX(), y, col.getZ()), dirt, 2);
				}
				for (int y = floor + 1; y <= Math.max(top, floor + clearHeight); y++) {
					this.level.setBlock(new BlockPos(col.getX(), y, col.getZ()), Blocks.AIR.defaultBlockState(), 2);
				}
			}
		}
	}

	// ------------------------------------------------------------------ block entities
	public void wallSign(int x, int y, int z, Direction facing, String... lines) {
		set(x, y, z, Blocks.DARK_OAK_WALL_SIGN.defaultBlockState().setValue(WallSignBlock.FACING, facing));
		if (this.level.getBlockEntity(pos(x, y, z)) instanceof SignBlockEntity sign) {
			SignText text = new SignText();
			for (int i = 0; i < Math.min(4, lines.length); i++) {
				text = text.setMessage(i, Component.literal(lines[i]));
			}
			sign.setText(text, true);
			sign.setWaxed(true);
		}
	}

	public void lectern(int x, int y, int z, Direction facing, ItemStack book) {
		set(x, y, z, Blocks.LECTERN.defaultBlockState().setValue(LecternBlock.FACING, facing).setValue(LecternBlock.HAS_BOOK, true));
		if (this.level.getBlockEntity(pos(x, y, z)) instanceof LecternBlockEntity lectern) {
			lectern.setBook(book);
		}
	}

	public void spawner(int x, int y, int z, EntityType<?> type) {
		BlockPos p = pos(x, y, z);
		this.level.setBlock(p, Blocks.SPAWNER.defaultBlockState(), 2);
		if (this.level.getBlockEntity(p) instanceof SpawnerBlockEntity spawner) {
			spawner.setEntityId(type, this.random);
		}
	}
}
