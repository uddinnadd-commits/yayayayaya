package thelostsoulsyeyeye.world.feature;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.SlabBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BedPart;
import net.minecraft.world.level.block.state.properties.SlabType;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

/**
 * Memory of a small home: a ruined one-room house with a child's bed, a table with a soul lantern,
 * old blood, and Ada's account of what happened to Mara.
 */
public class MemoryHouseFeature extends Feature<NoneFeatureConfiguration> {
	public MemoryHouseFeature() {
		super(NoneFeatureConfiguration.CODEC);
	}

	@Override
	public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> context) {
		StructureBuilder b = new StructureBuilder(context.level(), context.origin(), context.random());
		if (!b.groundOk(-6, -5, 6, 5, 3)) {
			return false;
		}
		b.terraform(-6, -5, 6, 5, 10);
		b.clear(-5, 0, -4, 5, 6, 4);

		// floor: rotten boards over bare earth
		for (int x = -4; x <= 4; x++) {
			for (int z = -3; z <= 3; z++) {
				b.set(x, -1, z, b.chance(0.12F) ? Blocks.COARSE_DIRT : b.pick(Blocks.DARK_OAK_PLANKS, Blocks.SPRUCE_PLANKS));
			}
		}

		// walls: the higher, the more has rotted away
		for (int y = 0; y <= 3; y++) {
			float decay = 0.05F + 0.06F * y;
			for (int x = -4; x <= 4; x++) {
				for (int z = -3; z <= 3; z++) {
					boolean wall = Math.abs(x) == 4 || Math.abs(z) == 3;
					if (!wall) {
						continue;
					}
					if (Math.abs(x) == 4 && Math.abs(z) == 3) {
						b.set(x, y, z, Blocks.DARK_OAK_LOG);
					} else if (!b.chance(decay)) {
						b.set(x, y, z, b.pick(Blocks.SPRUCE_PLANKS, Blocks.DARK_OAK_PLANKS, Blocks.STRIPPED_DARK_OAK_LOG));
					}
				}
			}
		}
		// doorway (no door: it has been open for a very long time) and windows
		b.clear(0, 0, -3, 0, 1, -3);
		b.set(0, 2, -3, Blocks.DARK_OAK_PLANKS);
		for (int y = 1; y <= 2; y++) {
			for (int sx : new int[]{-2, 2}) {
				if (b.chance(0.5F)) {
					b.set(sx, y, -3, Blocks.GLASS_PANE);
				} else {
					b.clear(sx, y, -3, sx, y, -3);
				}
			}
			if (b.chance(0.5F)) {
				b.set(-4, y, 0, Blocks.GLASS_PANE);
			} else {
				b.clear(-4, y, 0, -4, y, 0);
			}
			b.set(4, y, 0, Blocks.GLASS_PANE);
		}

		// roof: slabs, with a section caved in
		for (int x = -5; x <= 5; x++) {
			for (int z = -4; z <= 4; z++) {
				if (b.chance(0.72F)) {
					b.set(x, 4, z, Blocks.DARK_OAK_SLAB);
				}
			}
		}
		for (int x = -3; x <= 3; x++) {
			for (int z = -1; z <= 1; z++) {
				if (b.chance(0.5F)) {
					b.set(x, 5, z, Blocks.DARK_OAK_SLAB.defaultBlockState().setValue(SlabBlock.TYPE, SlabType.BOTTOM));
				}
			}
		}
		b.clear(1, 4, -4, 5, 6, -1);

		// old blood and soot on the floor (placed first so the furniture sits on top of it)
		for (int i = 0; i < 9; i++) {
			b.set(b.random.nextInt(7) - 3, 0, b.random.nextInt(5) - 2, i < 6 ? Blocks.RED_CARPET : Blocks.BLACK_CARPET);
		}

		// a child's bed against the back wall (head of the bed toward +z)
		BlockState bed = Blocks.RED_BED.defaultBlockState().setValue(BedBlock.FACING, Direction.SOUTH);
		b.set(-3, 0, 1, bed.setValue(BedBlock.PART, BedPart.FOOT));
		b.set(-3, 0, 2, bed.setValue(BedBlock.PART, BedPart.HEAD));
		b.set(-1, 0, 1, Blocks.SKELETON_SKULL);

		// table with a soul lantern that is somehow still lit
		b.set(2, 0, 0, Blocks.DARK_OAK_FENCE);
		b.set(2, 1, 0, Blocks.SOUL_LANTERN);

		// Ada's journal
		b.lectern(3, 0, -2, Direction.WEST, MemoryLore.book(MemoryLore.MARA));
		b.wallSign(0, 2, 2, Direction.NORTH, "MARA'S ROOM", "", "she is still", "in here");

		// cobwebs in the corners
		for (int sx : new int[]{-3, 3}) {
			for (int sz : new int[]{-2, 2}) {
				if (b.chance(0.7F)) {
					b.set(sx, 3, sz, Blocks.COBWEB);
				}
			}
		}
		for (int i = 0; i < 3; i++) {
			BlockPos p = b.pos(b.random.nextInt(9) - 4, 0, -4 - b.random.nextInt(2));
			if (b.level.getBlockState(p).isAir()) {
				b.level.setBlock(p, Blocks.DEAD_BUSH.defaultBlockState(), 2);
			}
		}
		return true;
	}
}
