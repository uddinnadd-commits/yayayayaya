package thelostsoulsyeyeye.fracture;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import thelostsoulsyeyeye.data.LostSoulsData;
import thelostsoulsyeyeye.net.ModNetworking;
import thelostsoulsyeyeye.registry.ModGameRules;
import thelostsoulsyeyeye.world.TheirWorld;
import thelostsoulsyeyeye.world.TheirWorldDirector;

/**
 * Server-side brain of the whole story:
 *  1. counts how long each player has spent under the Overworld sky (per-player, saved),
 *  2. tells the client how far along they are (the sky gets progressively wrong),
 *  3. when the countdown ends and the player can see the sky, runs the fracture cinematic,
 *  4. and finally drags them into Their World.
 */
public final class FractureManager {
	private FractureManager() {}

	/** player -> ticks into the cinematic. Present only while the cinematic is running. */
	private static final Map<UUID, Integer> EVENTS = new HashMap<>();
	private static final Map<UUID, Float> LAST_SENT = new HashMap<>();

	public static void init() {
		ServerTickEvents.END_SERVER_TICK.register(FractureManager::tick);
		ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> sync(handler.getPlayer(), server, true));
		ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
			UUID id = handler.getPlayer().getUUID();
			EVENTS.remove(id);
			LAST_SENT.remove(id);
		});
		ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> {
			EVENTS.remove(newPlayer.getUUID());
			ModNetworking.sendFractureEnd(newPlayer);
			sync(newPlayer, newPlayer.server, true);
		});
	}

	// ----------------------------------------------------------------------------- countdown
	public static long requiredTicks(MinecraftServer server, UUID id) {
		int minutes = server.getGameRules().getInt(ModGameRules.FRACTURE_MINUTES);
		if (minutes <= 0) {
			return Long.MAX_VALUE;
		}
		// every trip through makes the next one come sooner: the sky remembers
		int cycles = LostSoulsData.get(server).getCycles(id);
		double factor = Math.max(0.25D, 1.0D - 0.3D * cycles);
		return Math.max(200L, (long) (minutes * 1200L * factor));
	}

	public static float progressOf(MinecraftServer server, UUID id) {
		long required = requiredTicks(server, id);
		if (required == Long.MAX_VALUE) {
			return 0.0F;
		}
		return (float) Math.min(1.0D, (double) LostSoulsData.get(server).getTicks(id) / (double) required);
	}

	private static void tick(MinecraftServer server) {
		LostSoulsData data = LostSoulsData.get(server);
		for (ServerPlayer player : server.getPlayerList().getPlayers()) {
			UUID id = player.getUUID();
			Integer running = EVENTS.get(id);
			if (running != null) {
				tickEvent(server, data, player, running + 1);
				continue;
			}
			if (player.level().dimension() != Level.OVERWORLD || player.isSpectator() || !player.isAlive()) {
				continue;
			}
			long required = requiredTicks(server, id);
			if (required == Long.MAX_VALUE) {
				sync(player, server, false);
				continue;
			}
			long ticks = data.addTicks(id, 1L);
			float progress = (float) Math.min(1.0D, (double) ticks / (double) required);
			sendIfChanged(player, progress, false);
			if (progress >= 0.5F && server.getTickCount() % 100 == 0) {
				ModAdvancements.award(player, "sky_wrong");
			}
			if (ticks >= required && player.level().canSeeSky(player.blockPosition())) {
				beginEvent(player);
			}
		}
	}

	private static void sync(ServerPlayer player, MinecraftServer server, boolean force) {
		sendIfChanged(player, progressOf(server, player.getUUID()), force);
	}

	private static void sendIfChanged(ServerPlayer player, float progress, boolean force) {
		UUID id = player.getUUID();
		Float last = LAST_SENT.get(id);
		if (force || last == null || Math.abs(last - progress) >= 0.003F) {
			LAST_SENT.put(id, progress);
			ModNetworking.sendProgress(player, progress);
		}
	}

	// ----------------------------------------------------------------------------- cinematic
	public static boolean isRunning(ServerPlayer player) {
		return EVENTS.containsKey(player.getUUID());
	}

	public static void beginEvent(ServerPlayer player) {
		UUID id = player.getUUID();
		if (EVENTS.containsKey(id) || player.level().dimension() != Level.OVERWORLD) {
			return;
		}
		player.stopRiding();
		EVENTS.put(id, 0);
		sendIfChanged(player, 1.0F, true);
		// nothing is allowed to kill you before the sky gets its turn
		player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, FractureTimeline.TELEPORT + 40, 4, false, false, false));
		ModNetworking.sendFractureStart(player, player.getRandom().nextLong());
		ModAdvancements.award(player, "sky_cracks");
	}

	private static void tickEvent(MinecraftServer server, LostSoulsData data, ServerPlayer player, int t) {
		UUID id = player.getUUID();
		if (!player.isAlive() || player.level().dimension() != Level.OVERWORLD) {
			EVENTS.remove(id);
			ModNetworking.sendFractureEnd(player);
			return;
		}
		EVENTS.put(id, t);
		if (t == FractureTimeline.CRACK + 10) {
			player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 260, 5, false, false, false));
		}
		if (t == FractureTimeline.LEVITATE) {
			player.addEffect(new MobEffectInstance(MobEffects.LEVITATION, 110, 2, false, false, false));
		}
		if (t == FractureTimeline.FADE_START) {
			player.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 90, 0, false, false, false));
		}
		if (t >= FractureTimeline.TELEPORT) {
			EVENTS.remove(id);
			enterTheirWorld(server, player);
		}
	}

	// ----------------------------------------------------------------------------- travel
	public static void enterTheirWorld(MinecraftServer server, ServerPlayer player) {
		ServerLevel their = server.getLevel(TheirWorld.LEVEL_KEY);
		if (their == null) {
			player.sendSystemMessage(Component.translatable("message.thelostsouls.no_dimension").withStyle(ChatFormatting.RED));
			ModNetworking.sendFractureEnd(player);
			return;
		}
		UUID id = player.getUUID();
		EVENTS.remove(id);
		player.removeEffect(MobEffects.LEVITATION);
		player.removeEffect(MobEffects.MOVEMENT_SLOWDOWN);
		player.removeEffect(MobEffects.DARKNESS);

		BlockPos spawn = TheirWorld.findSpawn(their, player.getBlockX(), player.getBlockZ());
		player.teleportTo(their, spawn.getX() + 0.5D, spawn.getY(), spawn.getZ() + 0.5D, player.getYRot(), 0.0F);
		player.fallDistance = 0.0F;
		player.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 200, 0, false, false, false));

		LostSoulsData data = LostSoulsData.get(server);
		data.incrementCycles(id);
		data.setTicks(id, 0L);
		sendIfChanged(player, 0.0F, true);

		ModNetworking.sendArrive(player);
		TheirWorldDirector.markArrival(player);
		player.connection.send(new ClientboundSetTitlesAnimationPacket(30, 90, 50));
		player.connection.send(new ClientboundSetSubtitleTextPacket(Component.translatable("title.thelostsouls.arrive.subtitle").withStyle(ChatFormatting.GRAY)));
		player.connection.send(new ClientboundSetTitleTextPacket(Component.translatable("title.thelostsouls.arrive").withStyle(ChatFormatting.DARK_RED)));
		ModAdvancements.award(player, "their_world");
	}

	public static void leaveTheirWorld(MinecraftServer server, ServerPlayer player) {
		ServerLevel overworld = server.overworld();
		BlockPos spawn = overworld.getSharedSpawnPos();
		int y = overworld.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, spawn.getX(), spawn.getZ());
		player.teleportTo(overworld, spawn.getX() + 0.5D, y, spawn.getZ() + 0.5D, player.getYRot(), 0.0F);
		player.fallDistance = 0.0F;
		ModNetworking.sendFractureEnd(player);
		sync(player, server, true);
	}

	// ----------------------------------------------------------------------------- admin helpers
	public static void setProgressPercent(MinecraftServer server, ServerPlayer player, int percent) {
		long required = requiredTicks(server, player.getUUID());
		if (required == Long.MAX_VALUE) {
			required = 40L * 1200L;
		}
		LostSoulsData.get(server).setTicks(player.getUUID(), required * percent / 100L);
		sendIfChanged(player, percent / 100.0F, true);
	}

	public static void reset(MinecraftServer server, ServerPlayer player) {
		EVENTS.remove(player.getUUID());
		LostSoulsData.get(server).reset(player.getUUID());
		ModNetworking.sendFractureEnd(player);
		sendIfChanged(player, 0.0F, true);
	}
}
