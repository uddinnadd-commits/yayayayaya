package thelostsoulsyeyeye.entity;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.util.RandomSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.Level;
import thelostsoulsyeyeye.registry.ModSounds;

/** A dungeon guardian: an armoured memory that never stopped standing watch. Tough and hits hard. */
public class RemnantEntity extends CorruptedEntity {
	public RemnantEntity(EntityType<? extends RemnantEntity> type, Level level) {
		super(type, level);
		this.xpReward = 12;
	}

	public static AttributeSupplier.Builder createAttributes() {
		return createCorruptedAttributes(32.0D, 0.24D, 6.0D, 24.0D).add(Attributes.ARMOR, 6.0D);
	}

	@Override
	protected double attackSpeedModifier() {
		return 1.0D;
	}

	@Override
	public boolean isThem() {
		return false;
	}

	@Override
	protected int rollFeatures(RandomSource random) {
		return 0;
	}

	@Override
	protected SoundEvent getAmbientSound() {
		return ModSounds.ENTITY_REMNANT_AMBIENT;
	}

	@Override
	protected SoundEvent getHurtSound(DamageSource source) {
		return ModSounds.ENTITY_REMNANT_HURT;
	}

	@Override
	protected SoundEvent getDeathSound() {
		return ModSounds.ENTITY_REMNANT_DEATH;
	}

	@Override
	protected SoundEvent getAttackSound() {
		return ModSounds.ENTITY_REMNANT_ATTACK;
	}
}
