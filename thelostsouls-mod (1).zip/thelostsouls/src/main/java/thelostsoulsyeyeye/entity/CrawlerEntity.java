package thelostsoulsyeyeye.entity;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.util.RandomSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.goal.LeapAtTargetGoal;
import net.minecraft.world.level.Level;
import thelostsoulsyeyeye.registry.ModSounds;

/** A legless thing that drags itself along by its arms and leaps the last few blocks. */
public class CrawlerEntity extends CorruptedEntity {
	public CrawlerEntity(EntityType<? extends CrawlerEntity> type, Level level) {
		super(type, level);
	}

	public static AttributeSupplier.Builder createAttributes() {
		return createCorruptedAttributes(18.0D, 0.30D, 4.0D, 64.0D);
	}

	@Override
	protected void registerGoals() {
		super.registerGoals();
		this.goalSelector.addGoal(3, new LeapAtTargetGoal(this, 0.5F));
	}

	@Override
	protected double attackSpeedModifier() {
		return 1.3D;
	}

	@Override
	public boolean isThem() {
		return true;
	}

	@Override
	protected int rollFeatures(RandomSource random) {
		int allowed = Deformity.MISSING_ARM_L | Deformity.MISSING_ARM_R | Deformity.EXTRA_ARM | Deformity.HANGING_JAW | Deformity.RIBS;
		return Deformity.roll(random, allowed, 1, 3);
	}

	@Override
	protected SoundEvent getAmbientSound() {
		return ModSounds.ENTITY_CRAWLER_AMBIENT;
	}

	@Override
	protected SoundEvent getHurtSound(DamageSource source) {
		return ModSounds.ENTITY_CRAWLER_HURT;
	}

	@Override
	protected SoundEvent getDeathSound() {
		return ModSounds.ENTITY_CRAWLER_DEATH;
	}

	@Override
	protected SoundEvent getAttackSound() {
		return ModSounds.ENTITY_CRAWLER_ATTACK;
	}
}
