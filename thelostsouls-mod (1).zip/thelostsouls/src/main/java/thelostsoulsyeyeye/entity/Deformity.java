package thelostsoulsyeyeye.entity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import net.minecraft.util.RandomSource;

/**
 * Bit flags describing how a corrupted soul has been "wrong-ed". Each spawned creature rolls a random
 * subset (synced to the client) and its model hides/shows parts accordingly: missing limbs show a raw
 * stump, extra limbs and second heads sprout, ribs burst out, jaws hang open.
 */
public final class Deformity {
	public static final int MISSING_ARM_L = 1;
	public static final int MISSING_ARM_R = 2;
	public static final int MISSING_LEG = 4;
	public static final int RIBS = 8;
	public static final int HANGING_JAW = 16;
	public static final int EXTRA_ARM = 32;
	public static final int SECOND_HEAD = 64;

	private static final int[] ALL = {MISSING_ARM_L, MISSING_ARM_R, MISSING_LEG, RIBS, HANGING_JAW, EXTRA_ARM, SECOND_HEAD};

	private Deformity() {}

	/** Picks between {@code min} and {@code max} distinct flags out of {@code allowedMask}. */
	public static int roll(RandomSource random, int allowedMask, int min, int max) {
		List<Integer> pool = new ArrayList<>();
		for (int flag : ALL) {
			if ((allowedMask & flag) != 0) {
				pool.add(flag);
			}
		}
		Collections.shuffle(pool, new java.util.Random(random.nextLong()));
		int count = min + (max > min ? random.nextInt(max - min + 1) : 0);
		int result = 0;
		for (int i = 0; i < Math.min(count, pool.size()); i++) {
			result |= pool.get(i);
		}
		return result;
	}
}
