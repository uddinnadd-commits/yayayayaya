#!/usr/bin/env python3
"""
Static cross-reference checks (no Minecraft needed). Catches the typos that would otherwise only show up
as a crash on world load:  python3 tools/check_integrity.py

  * every ModSounds.X used in Java exists, every sounds.json file exists on disk
  * every texture / model / sound path mentioned in Java or JSON exists
  * every registry id used in data JSON (items, entities, features, biomes, ...) is defined by this mod or vanilla-looking
  * every model field used in setupAnim exists, every animation bone name exists in the model
  * every translation key used in Java exists in en_us.json
"""
import glob
import json
import os
import re
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
os.chdir(ROOT)
NS = "thelostsouls"
problems = []


def bad(msg):
    problems.append(msg)


def read(p):
    with open(p, encoding="utf-8") as f:
        return f.read()


java = {p: read(p) for p in glob.glob("src/**/*.java", recursive=True)}
alljava = "\n".join(java.values())

# ---- 1. sounds
mod_sounds = read("src/main/java/thelostsoulsyeyeye/registry/ModSounds.java")
defined = set(re.findall(r"SoundEvent (\w+) = register", mod_sounds))
used = set(re.findall(r"ModSounds\.(\w+)", alljava)) - {"init"}
for u in sorted(used - defined):
    bad(f"ModSounds.{u} is used but not defined")
sj = json.load(open("src/main/resources/assets/thelostsouls/sounds.json"))
for event, entry in sj.items():
    for s in entry["sounds"]:
        name = s if isinstance(s, str) else s["name"]
        path = f"src/main/resources/assets/{NS}/sounds/{name.split(':')[1]}.ogg"
        if not os.path.exists(path):
            bad(f"sounds.json {event}: missing file {path}")
registered_events = set(sj.keys())
for ev in re.findall(r'register\("([\w.]+)"\)', mod_sounds):
    if ev not in registered_events:
        bad(f"sound event {ev} registered in Java but missing from sounds.json")
unused = sorted(defined - used)
if unused:
    print("  note: sound constants defined but never used in Java (fine, just spare):", ", ".join(unused))

# ---- 2. textures referenced by path in Java
for m in re.finditer(r'"(textures/[\w/]+\.png)"', alljava):
    p = f"src/main/resources/assets/{NS}/{m.group(1)}"
    if not os.path.exists(p):
        bad(f"Java references missing texture {p}")
for name in re.findall(r'"(\w+)", [\d.]+F\)\);', read("src/client/java/thelostsoulsyeyeye/client/ThelostsoulsClient.java")):
    for suffix in ("", "_glow"):
        p = f"src/main/resources/assets/{NS}/textures/entity/{name}{suffix}.png"
        if not os.path.exists(p):
            bad(f"renderer needs {p}")

# ---- 3. every json resource reference
def id_exists(rid, kind):
    ns, path = rid.split(":", 1) if ":" in rid else ("minecraft", rid)
    if ns != NS:
        return True  # vanilla; cannot verify offline
    if kind == "texture":
        return os.path.exists(f"src/main/resources/assets/{NS}/textures/{path}.png")
    if kind == "model":
        return os.path.exists(f"src/main/resources/assets/{NS}/models/{path}.json")
    return True

for p in glob.glob("src/main/resources/assets/**/*.json", recursive=True):
    d = json.load(open(p, encoding="utf-8"))
    def walk(o):
        if isinstance(o, dict):
            for k, v in o.items():
                if k == "textures" and isinstance(v, dict):
                    for t in v.values():
                        if isinstance(t, str) and not id_exists(t, "texture"):
                            bad(f"{p}: missing texture {t}")
                elif k == "model" and isinstance(v, str) and not id_exists(v, "model"):
                    bad(f"{p}: missing model {v}")
                elif k == "parent" and isinstance(v, str) and not id_exists(v, "model"):
                    bad(f"{p}: missing parent model {v}")
                else:
                    walk(v)
        elif isinstance(o, list):
            for i in o:
                walk(i)
    walk(d)

# ---- 4. registry ids used in data
items = {"sky_shard", "memory_fragment", "shardblade", "memory_cache"} | {f"{e}_spawn_egg" for e in ("hollow_walker", "crawler", "stretched", "echo_hound", "remnant")}
for n in items:
    if f'"{n}"' not in read("src/main/java/thelostsoulsyeyeye/registry/ModItems.java") and n != "memory_cache":
        bad(f"item {n} missing from ModItems")
features = set(re.findall(r'register\("(\w+)", new', read("src/main/java/thelostsoulsyeyeye/registry/ModFeatures.java")))
placed = {os.path.basename(p)[:-5] for p in glob.glob(f"src/main/resources/data/{NS}/worldgen/placed_feature/*.json")}
configured = {os.path.basename(p)[:-5] for p in glob.glob(f"src/main/resources/data/{NS}/worldgen/configured_feature/*.json")}
biomes = {os.path.basename(p)[:-5] for p in glob.glob(f"src/main/resources/data/{NS}/worldgen/biome/*.json")}
for p in glob.glob(f"src/main/resources/data/{NS}/worldgen/configured_feature/*.json"):
    t = json.load(open(p))["type"]
    if t.split(":")[1] not in features:
        bad(f"{p}: feature type {t} is not registered in ModFeatures")
for p in glob.glob(f"src/main/resources/data/{NS}/worldgen/placed_feature/*.json"):
    f = json.load(open(p))["feature"]
    if f.split(":")[1] not in configured:
        bad(f"{p}: configured feature {f} missing")
for p in glob.glob(f"src/main/resources/data/{NS}/worldgen/biome/*.json"):
    b = json.load(open(p))
    if len(b["features"]) != 11:
        bad(f"{p}: biome needs exactly 11 feature steps")
    for step in b["features"]:
        for f in step:
            if f.startswith(NS + ":") and f.split(":")[1] not in placed:
                bad(f"{p}: placed feature {f} missing")
    s = b["effects"]["ambient_sound"].split(":")[1]
    if s not in registered_events:
        bad(f"{p}: ambient sound {s} not a registered event")
    for k in ("additions_sound",):
        s = b["effects"][k]["sound"]
        if s.startswith(NS + ":") and s.split(":")[1] not in registered_events:
            bad(f"{p}: {k} {s} not a registered event")
dim = json.load(open(f"src/main/resources/data/{NS}/dimension/their_world.json"))
for e in dim["generator"]["biome_source"]["biomes"]:
    if e["biome"].split(":")[1] not in biomes:
        bad(f"dimension references missing biome {e['biome']}")
if not os.path.exists(f"src/main/resources/data/{NS}/dimension_type/their_world.json"):
    bad("dimension_type their_world missing")
if not os.path.exists(f"src/main/resources/data/{NS}/worldgen/noise_settings/their_world.json"):
    bad("noise_settings their_world missing")
ns_json = json.load(open(f"src/main/resources/data/{NS}/worldgen/noise_settings/their_world.json"))
for key, val in ns_json["noise_router"].items():
    def refs(o):
        if isinstance(o, str) and o.startswith(NS + ":"):
            yield o
        elif isinstance(o, dict):
            for v in o.values():
                yield from refs(v)
    for r in refs(val):
        rel = r.split(":")[1]
        if not (os.path.exists(f"src/main/resources/data/{NS}/worldgen/density_function/{rel}.json") or os.path.exists(f"src/main/resources/data/{NS}/worldgen/noise/{rel}.json")):
            bad(f"noise_router.{key} references missing {r}")
for p in glob.glob(f"src/main/resources/data/{NS}/worldgen/density_function/**/*.json", recursive=True):
    for r in re.findall(r'"noise": "(thelostsouls:[\w/]+)"', read(p)):
        if not os.path.exists(f"src/main/resources/data/{NS}/worldgen/noise/{r.split(':')[1]}.json"):
            bad(f"{p}: missing noise {r}")
# loot tables referenced from Java
for lt in re.findall(r'Thelostsouls\.id\("(chests/[\w/]+)"\)', alljava):
    if not os.path.exists(f"src/main/resources/data/{NS}/loot_tables/{lt}.json"):
        bad(f"missing loot table {lt}")
for p in glob.glob(f"src/main/resources/data/{NS}/loot_tables/**/*.json", recursive=True) + glob.glob(f"src/main/resources/data/{NS}/recipes/*.json") + glob.glob(f"src/main/resources/data/{NS}/advancements/*.json"):
    for r in re.findall(r'"(?:name|item)": "thelostsouls:(\w+)"', read(p)):
        if r not in items:
            bad(f"{p}: unknown item {NS}:{r}")
for a in re.findall(r'ModAdvancements\.award\(\w+, "(\w+)"\)', alljava):
    if not os.path.exists(f"src/main/resources/data/{NS}/advancements/{a}.json"):
        bad(f"missing advancement {a}")
for p in glob.glob(f"src/main/resources/data/{NS}/advancements/*.json"):
    par = json.load(open(p))["parent"]
    if par.startswith(NS + ":") and not os.path.exists(f"src/main/resources/data/{NS}/advancements/{par.split(':')[1]}.json"):
        bad(f"{p}: missing parent advancement {par}")

# ---- 5. models: fields used vs defined, bones used in animations
for mp in glob.glob("src/client/java/**/model/*Model.java", recursive=True):
    src = read(mp)
    fields = set(re.findall(r"private final ModelPart (\w+);", src))
    fields.add("root")
    body = src[src.index("public void setupAnim"):]
    for f in set(re.findall(r"this\.(\w+)\.", body)):
        if f not in fields and f not in ("root",):
            bad(f"{mp}: setupAnim uses this.{f} but no such part")
    parts = set(re.findall(r'addOrReplaceChild\("(\w+)"', src))
    cls = os.path.basename(mp)[:-10]
    anim = {"HollowWalker": "Walker", "Crawler": "Crawler", "Stretched": "Stretched", "EchoHound": "EchoHound", "Remnant": "Remnant"}[cls]
    ap = f"src/client/java/thelostsoulsyeyeye/client/model/{anim}Animations.java"
    for bone in set(re.findall(r'addAnimation\("(\w+)"', read(ap))):
        if bone not in parts:
            bad(f"{ap}: bone {bone} not in {cls}Model parts")
    ent = re.search(r"HierarchicalModel<(\w+)>", src).group(1)
    ep = f"src/main/java/thelostsoulsyeyeye/entity/{ent}.java"
    if not os.path.exists(ep):
        bad(f"{mp}: entity {ent} missing")
    elif "isObserved" in body and "isObserved" not in read(ep):
        bad(f"{ep}: model calls isObserved() but entity lacks it")

# ---- 6. translation keys used in Java / loot
en = json.load(open(f"src/main/resources/assets/{NS}/lang/en_us.json"))
for k in re.findall(r'Component\.translatable\("([\w.]+)"', alljava) + re.findall(r'(?:"|\()(item\.thelostsouls\.[\w.]+)"', alljava) + re.findall(r'(?:"|\()(message\.thelostsouls\.[\w.]+)"', alljava):
    if k not in en:
        bad(f"missing translation key {k}")
for ev in registered_events:
    entry = sj[ev]
    if "subtitle" in entry and entry["subtitle"] not in en:
        bad(f"missing subtitle key {entry['subtitle']}")
for n in ("hollow_walker", "crawler", "stretched", "echo_hound", "remnant"):
    if f"entity.{NS}.{n}" not in en:
        bad(f"missing entity name for {n}")

# ---- 7. the entity types in ModEntities have a layer, renderer, loot table and egg
for n in re.findall(r'register\("(\w+)",\s*FabricEntityTypeBuilder', read("src/main/java/thelostsoulsyeyeye/registry/ModEntities.java")):
    if not os.path.exists(f"src/main/resources/data/{NS}/loot_tables/entities/{n}.json"):
        bad(f"no loot table for entity {n}")
    if f'"{n}"' not in read("src/client/java/thelostsoulsyeyeye/client/model/ModModelLayers.java"):
        bad(f"no model layer for entity {n}")

if problems:
    print(f"\n{len(problems)} PROBLEM(S):")
    for p in problems:
        print("  -", p)
    sys.exit(1)
print("integrity OK: all cross-references resolve")
