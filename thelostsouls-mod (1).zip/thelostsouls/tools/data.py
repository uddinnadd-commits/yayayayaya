"""Datapack + resource-pack JSON (written from Python dicts so every file is guaranteed valid)."""
import json
from common import *

NS = MOD_ID


def jw(path, obj):
    write_text(path, json.dumps(obj, indent=2) + "\n")


def data(rel, obj):
    jw(os.path.join(DATA, rel), obj)


def asset(rel, obj):
    jw(os.path.join(ASSETS, rel), obj)


def rgb(hexstr):
    return int(hexstr.lstrip("#"), 16)


# ----------------------------------------------------------------------------------- dimension
def dimension():
    data("dimension_type/their_world.json", {
        "ultrawarm": False, "natural": False, "coordinate_scale": 1.0,
        "has_skylight": True, "has_ceiling": False,
        "ambient_light": 0.06,
        "fixed_time": 13000,                 # eternal dusk; tune this to taste (6000 = noon, 18000 = midnight)
        "monster_spawn_light_level": 7, "monster_spawn_block_light_limit": 0,
        "piglin_safe": False, "bed_works": False, "respawn_anchor_works": False, "has_raids": False,
        "logical_height": 128, "min_y": 0, "height": 128,
        "infiniburn": "#minecraft:infiniburn_overworld",
        "effects": "minecraft:overworld",    # the sky/cloud/weather are replaced in code
    })

    def entry(biome, t_lo, t_hi):
        return {"biome": f"{NS}:{biome}",
                "parameters": {"temperature": [t_lo, t_hi], "humidity": [-1.0, 1.0], "continentalness": [-1.0, 1.0],
                               "erosion": [-1.0, 1.0], "depth": [-1.0, 1.0], "weirdness": [-1.0, 1.0], "offset": 0.0}}

    data("dimension/their_world.json", {
        "type": f"{NS}:their_world",
        "generator": {
            "type": "minecraft:noise",
            "settings": f"{NS}:their_world",
            "biome_source": {"type": "minecraft:multi_noise",
                             "biomes": [entry("dead_plains", -1.0, 0.1), entry("dead_forest", 0.1, 1.0)]},
        },
    })

    data("worldgen/noise/hills.json", {"firstOctave": -6, "amplitudes": [1.0, 1.0, 0.5, 0.25]})
    data("worldgen/noise/biome_noise.json", {"firstOctave": -8, "amplitudes": [1.0, 1.0, 0.5]})

    # terrain: density > 0 is solid.  A vertical gradient crosses zero at y=68; two noises push it up and down.
    data("worldgen/density_function/their_world/terrain.json", {
        "type": "minecraft:add",
        "argument1": {"type": "minecraft:y_clamped_gradient", "from_y": 36, "to_y": 100, "from_value": 1.0, "to_value": -1.0},
        "argument2": {
            "type": "minecraft:add",
            "argument1": {"type": "minecraft:mul", "argument1": 0.55,
                          "argument2": {"type": "minecraft:noise", "noise": f"{NS}:hills", "xz_scale": 0.35, "y_scale": 0.0}},
            "argument2": {"type": "minecraft:mul", "argument1": 0.10,
                          "argument2": {"type": "minecraft:noise", "noise": f"{NS}:hills", "xz_scale": 1.4, "y_scale": 0.9}},
        },
    })

    top_dirt_rule = {
        "type": "minecraft:condition",
        "if_true": {"type": "minecraft:stone_depth", "offset": 0, "surface_type": "floor", "add_surface_depth": False, "secondary_depth_range": 0},
        "then_run": {"type": "minecraft:sequence", "sequence": [
            {"type": "minecraft:condition",
             "if_true": {"type": "minecraft:noise_threshold", "noise": "minecraft:surface", "min_threshold": 0.12, "max_threshold": 100.0},
             "then_run": {"type": "minecraft:block", "result_state": {"Name": "minecraft:coarse_dirt"}}},
            {"type": "minecraft:block", "result_state": {"Name": "minecraft:dirt"}},
        ]},
    }
    data("worldgen/noise_settings/their_world.json", {
        "sea_level": 30,
        "disable_mob_generation": True,
        "aquifers_enabled": False,
        "ore_veins_enabled": False,
        "legacy_random_source": False,
        "default_block": {"Name": "minecraft:dirt"},
        "default_fluid": {"Name": "minecraft:water", "Properties": {"level": "0"}},
        "noise": {"min_y": 0, "height": 128, "size_horizontal": 1, "size_vertical": 2},
        "spawn_target": [],
        "noise_router": {
            "barrier": 0, "fluid_level_floodedness": 0, "fluid_level_spread": 0, "lava": 0,
            "temperature": {"type": "minecraft:mul", "argument1": 2.0,
                            "argument2": {"type": "minecraft:noise", "noise": f"{NS}:biome_noise", "xz_scale": 0.25, "y_scale": 0.0}},
            "vegetation": 0, "continents": 0, "erosion": 0, "depth": 0, "ridges": 0,
            "initial_density_without_jaggedness": f"{NS}:their_world/terrain",
            "final_density": {"type": "minecraft:interpolated", "argument": f"{NS}:their_world/terrain"},
            "vein_toggle": 0, "vein_ridged": 0, "vein_gap": 0,
        },
        "surface_rule": {"type": "minecraft:sequence", "sequence": [
            {"type": "minecraft:condition",
             "if_true": {"type": "minecraft:vertical_gradient", "random_name": "minecraft:bedrock_floor",
                         "true_at_and_below": {"above_bottom": 0}, "false_at_and_above": {"above_bottom": 5}},
             "then_run": {"type": "minecraft:block", "result_state": {"Name": "minecraft:bedrock"}}},
            top_dirt_rule,
        ]},
    })


# ----------------------------------------------------------------------------------- features
def placed(name, feature, rarity=None, count=None):
    mods = []
    if rarity:
        mods.append({"type": "minecraft:rarity_filter", "chance": rarity})
    if count:
        mods.append({"type": "minecraft:count", "count": count})
    mods += [{"type": "minecraft:in_square"}, {"type": "minecraft:heightmap", "heightmap": "WORLD_SURFACE_WG"}, {"type": "minecraft:biome"}]
    data(f"worldgen/placed_feature/{name}.json", {"feature": f"{NS}:{feature}", "placement": mods})


def biome(name, fog, sky, trees_placed, structures, vault):
    empty = [[] for _ in range(11)]
    empty[3] = [f"{NS}:{vault}"]                            # UNDERGROUND_STRUCTURES
    empty[4] = [f"{NS}:{s}" for s in structures]            # SURFACE_STRUCTURES
    empty[9] = [f"{NS}:{trees_placed}", "minecraft:patch_dead_bush"]   # VEGETAL_DECORATION
    data(f"worldgen/biome/{name}.json", {
        "has_precipitation": False, "temperature": 0.5, "downfall": 0.0,
        "effects": {
            "sky_color": rgb(sky), "fog_color": rgb(fog), "water_color": rgb("#3a2030"), "water_fog_color": rgb("#1a0a14"),
            "grass_color": rgb("#3b2a22"), "foliage_color": rgb("#2a1f18"),
            "ambient_sound": f"{NS}:ambient.their_world",
            "additions_sound": {"sound": f"{NS}:ambient.whisper_far", "tick_chance": 0.004},
            "mood_sound": {"sound": "minecraft:ambient.cave", "tick_delay": 6000, "block_search_extent": 8, "offset": 2.0},
            "particle": {"probability": 0.02, "options": {"type": "minecraft:ash"}},
        },
        "spawners": {c: [] for c in ("monster", "creature", "ambient", "axolotls", "underground_water_creature", "water_creature", "water_ambient", "misc")},
        "spawn_costs": {},
        "carvers": {},
        "features": empty,
    })


def worldgen_features():
    for f in ("dead_tree", "memory_house", "playground", "waiting_hall", "obelisk", "memory_vault"):
        data(f"worldgen/configured_feature/{f}.json", {"type": f"{NS}:{f}", "config": {}})
    placed("dead_tree_sparse", "dead_tree", count=2)
    placed("dead_tree_dense", "dead_tree", count=9)
    placed("memory_house", "memory_house", rarity=22)
    placed("playground", "playground", rarity=30)
    placed("waiting_hall", "waiting_hall", rarity=55)
    placed("obelisk", "obelisk", rarity=26)
    placed("memory_vault", "memory_vault", rarity=26)
    biome("dead_plains", "#2a0f12", "#120508", "dead_tree_sparse", ["memory_house", "playground", "waiting_hall", "obelisk"], "memory_vault")
    biome("dead_forest", "#1a090c", "#0c0407", "dead_tree_dense", ["memory_house", "obelisk"], "memory_vault")


# ----------------------------------------------------------------------------------- loot
def item(name, weight=None, count=None, functions=None):
    e = {"type": "minecraft:item", "name": name}
    if weight:
        e["weight"] = weight
    fn = list(functions or [])
    if count:
        fn.append({"function": "minecraft:set_count", "count": {"type": "minecraft:uniform", "min": count[0], "max": count[1]}})
    if fn:
        e["functions"] = fn
    return e


def loot():
    data("loot_tables/chests/memory_vault.json", {"type": "minecraft:chest", "pools": [
        {"rolls": {"type": "minecraft:uniform", "min": 4, "max": 6}, "entries": [
            item("minecraft:diamond", 4, (1, 3)),
            item("minecraft:emerald", 6, (2, 6)),
            item("minecraft:gold_ingot", 8, (3, 8)),
            item("minecraft:iron_ingot", 10, (4, 10)),
            item("minecraft:golden_apple", 5),
            item("minecraft:enchanted_golden_apple", 1),
            item("minecraft:ender_pearl", 4, (1, 3)),
            item("minecraft:totem_of_undying", 1),
            item("minecraft:experience_bottle", 6, (2, 6)),
            item("minecraft:name_tag", 3),
            item("minecraft:book", 5, functions=[{"function": "minecraft:enchant_with_levels", "levels": {"type": "minecraft:uniform", "min": 20, "max": 39}, "treasure": True}]),
        ]},
        {"rolls": 1, "entries": [item(f"{NS}:memory_fragment", count=(2, 4))]},
        {"rolls": 1, "entries": [item(f"{NS}:sky_shard", count=(2, 5))]},
        {"rolls": 1, "entries": [item(f"{NS}:shardblade", 1), {"type": "minecraft:empty", "weight": 3}]},
    ]})
    data("loot_tables/blocks/memory_cache.json", {"type": "minecraft:block", "pools": []})

    def mob(name, flesh, rare_item, chance):
        pools = []
        if flesh:
            pools.append({"rolls": 1, "entries": [item(flesh[0], count=flesh[1])]})
        pools.append({"rolls": 1, "entries": [item(rare_item)],
                      "conditions": [{"condition": "minecraft:killed_by_player"}, {"condition": "minecraft:random_chance", "chance": chance}]})
        data(f"loot_tables/entities/{name}.json", {"type": "minecraft:entity", "pools": pools})

    mob("hollow_walker", ("minecraft:rotten_flesh", (0, 2)), f"{NS}:sky_shard", 0.08)
    mob("crawler", ("minecraft:bone", (0, 2)), f"{NS}:sky_shard", 0.08)
    mob("stretched", ("minecraft:bone", (1, 3)), f"{NS}:sky_shard", 0.25)
    mob("echo_hound", None, f"{NS}:memory_fragment", 0.35)
    mob("remnant", ("minecraft:iron_nugget", (0, 4)), f"{NS}:memory_fragment", 0.45)


# ----------------------------------------------------------------------------------- advancements / recipes
def advancements():
    def adv(name, parent, icon, frame, hidden, rewards=None):
        d = {"display": {"icon": {"item": icon},
                         "title": {"translate": f"advancement.{NS}.{name}.title"},
                         "description": {"translate": f"advancement.{NS}.{name}.description"},
                         "frame": frame, "show_toast": True, "announce_to_chat": frame != "task", "hidden": hidden},
             "parent": parent, "criteria": {"trigger": {"trigger": "minecraft:impossible"}}}
        if rewards:
            d["rewards"] = rewards
        data(f"advancements/{name}.json", d)

    adv("sky_wrong", "minecraft:story/root", f"{NS}:sky_shard", "task", True)
    adv("sky_cracks", f"{NS}:sky_wrong", "minecraft:glass", "goal", True)
    adv("their_world", f"{NS}:sky_cracks", f"{NS}:memory_fragment", "goal", True)
    adv("memory_vault", f"{NS}:their_world", f"{NS}:memory_cache", "challenge", True, {"experience": 200})


def recipes():
    data("recipes/shardblade.json", {
        "type": "minecraft:crafting_shaped", "category": "equipment",
        "pattern": ["S", "S", "T"],
        "key": {"S": {"item": f"{NS}:sky_shard"}, "T": {"item": "minecraft:stick"}},
        "result": {"item": f"{NS}:shardblade"},
    })


# ----------------------------------------------------------------------------------- resource pack
def models():
    asset("blockstates/memory_cache.json", {"variants": {
        "opened=false": {"model": f"{NS}:block/memory_cache"},
        "opened=true": {"model": f"{NS}:block/memory_cache_opened"}}})
    for name, top in (("memory_cache", "memory_cache_top"), ("memory_cache_opened", "memory_cache_top_open")):
        asset(f"models/block/{name}.json", {"parent": "minecraft:block/cube_bottom_top", "textures": {
            "top": f"{NS}:block/{top}", "bottom": f"{NS}:block/memory_cache_bottom", "side": f"{NS}:block/memory_cache_side"}})
    asset("models/item/memory_cache.json", {"parent": f"{NS}:block/memory_cache"})
    for name in ("sky_shard", "memory_fragment"):
        asset(f"models/item/{name}.json", {"parent": "minecraft:item/generated", "textures": {"layer0": f"{NS}:item/{name}"}})
    asset("models/item/shardblade.json", {"parent": "minecraft:item/handheld", "textures": {"layer0": f"{NS}:item/shardblade"}})
    for egg in ("hollow_walker", "crawler", "stretched", "echo_hound", "remnant"):
        asset(f"models/item/{egg}_spawn_egg.json", {"parent": "minecraft:item/template_spawn_egg"})
    asset("particles/glass_shard.json", {"textures": [f"{NS}:glass_shard"]})


def lang():
    en = {
        "itemGroup.thelostsouls": "The Lost Souls",
        "item.thelostsouls.sky_shard": "Sky Shard",
        "item.thelostsouls.sky_shard.lore": "Cold. It is still faintly cracking.",
        "item.thelostsouls.memory_fragment": "Memory Fragment",
        "item.thelostsouls.memory_fragment.lore": "Someone was happy, once.",
        "item.thelostsouls.shardblade": "Shardblade",
        "item.thelostsouls.shardblade.lore": "Its edge pins the corrupted for a moment.",
        "block.thelostsouls.memory_cache": "Memory Cache",
        "item.thelostsouls.hollow_walker_spawn_egg": "Hollow Walker Spawn Egg",
        "item.thelostsouls.crawler_spawn_egg": "Crawler Spawn Egg",
        "item.thelostsouls.stretched_spawn_egg": "Stretched Spawn Egg",
        "item.thelostsouls.echo_hound_spawn_egg": "Echo Hound Spawn Egg",
        "item.thelostsouls.remnant_spawn_egg": "Remnant Spawn Egg",
        "entity.thelostsouls.hollow_walker": "Hollow Walker",
        "entity.thelostsouls.crawler": "Crawler",
        "entity.thelostsouls.stretched": "The Stretched",
        "entity.thelostsouls.echo_hound": "Echo Hound",
        "entity.thelostsouls.remnant": "Remnant",
        "gamerule.lostSoulsFractureMinutes": "Minutes until the sky cracks",
        "gamerule.lostSoulsFractureMinutes.description": "Minutes of Overworld play before a player is pulled into Their World. 0 disables it.",
        "gamerule.lostSoulsHunt": "Them hunt players",
        "gamerule.lostSoulsHunt.description": "Whether Them keep spawning around players inside Their World.",
        "message.thelostsouls.cache_guarded": "The memories are still guarded... (%s remain)",
        "message.thelostsouls.cache_empty": "There is nothing left in it.",
        "message.thelostsouls.no_dimension": "Their World could not be found. Is the mod's data pack loaded?",
        "title.thelostsouls.arrive": "THEIR WORLD",
        "title.thelostsouls.arrive.subtitle": "You were not meant to see this.",
        "advancement.thelostsouls.sky_wrong.title": "Something Is Wrong With the Sky",
        "advancement.thelostsouls.sky_wrong.description": "Spend long enough under the sky for it to start to change.",
        "advancement.thelostsouls.sky_cracks.title": "It Was Never a Sky",
        "advancement.thelostsouls.sky_cracks.description": "Watch the sky break open.",
        "advancement.thelostsouls.their_world.title": "Their World",
        "advancement.thelostsouls.their_world.description": "Be dragged through the crack. Do not stop moving.",
        "advancement.thelostsouls.memory_vault.title": "What They Kept",
        "advancement.thelostsouls.memory_vault.description": "Clear a Memory Vault and open the Memory Cache.",
    }
    sub_path = os.path.join(ASSETS, "lang", "_subtitles.json")
    if os.path.exists(sub_path):
        with open(sub_path, encoding="utf-8") as f:
            en.update(json.load(f))
        os.remove(sub_path)
    jw(os.path.join(ASSETS, "lang", "en_us.json"), en)


def mod_metadata():
    path = os.path.join(RES, "fabric.mod.json")
    with open(path, encoding="utf-8") as f:
        meta = json.load(f)
    meta["name"] = "The Lost Souls"
    meta["description"] = ("Souls were guided into Minecraft with the promise of a palace to rest in. There is no palace. "
                           "The sky is starting to crack. A horror mod: a creeping corrupted sky, a tentacle that breaks it open, "
                           "a hostile dimension of dirt, dead trees and Them, memories left in ruins, and vaults to loot.")
    meta.pop("mixins", None)
    jw(path, meta)


def build_all():
    dimension()
    worldgen_features()
    loot()
    advancements()
    recipes()
    models()
    lang()
    mod_metadata()
    print("  datapack, models, lang, fabric.mod.json done")


if __name__ == "__main__":
    build_all()
